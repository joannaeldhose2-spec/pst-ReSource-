# ReSource — Resource Intelligence Platform 🌱

> **"Waste isn't waste until we understand its potential."**

ReSource is a modern, responsive climate-tech web application built for the Circular Economy & Sustainable Materials Hackathon. It characterizes organic and industrial side-streams by moisture tier, cellular composition, and physical state to calculate the highest-value valorization pathways and connect feedstocks to regional circular off-takers.

---

## 🌟 Key Features

1. **Feedstock Characterization Engine**:
   - Covers 6 high-impact resource streams:
     - 🍌 **Banana Peels** (*Musa acuminata* — high-pectin fruit residuals)
     - ☕ **Coffee Grounds** (Spent beverage side-stream with 12% lipids)
     - 🥥 **Coconut Husk** (Lignocellulosic fibers with >42% dense lignin)
     - 🌾 **Rice Waste** (High amorphous biogenic silica straw & hulls)
     - 🍊 **Citrus Peels** (High-terpene D-Limonene & methoxyl pectin stream)
     - 🥗 **Food Scraps** (Heterogeneous pre/post-consumer organics)
   - Dynamic moisture state indexing: **Fresh**, **Wet**, and **Dry**.
   - Dynamic real-time biochemical profile previewing.

2. **Valorization Hierarchy & "BEST NEXT USE" Card**:
   - Multi-cascade ranking from best to worst based on biochemical affinity, economic yield, and lifecycle carbon mitigation.
   - Prominently showcases the **#1 Top Pick** with an in-depth scientific explanation of why it was selected over low-tier alternatives.

3. **1-Click Hackathon Presets**:
   - Instant testing buttons in the hero section for judges and users:
     - *10 kg Fresh Banana Peels* → 94% Biomaterial Synthesis
     - *50 kg Wet Coffee Grounds* → High-Caloric Biogas Digestion
     - *120 kg Dry Coconut Husk* → 97% PFAS Water Remediation Carbon
     - *25 kg Fresh Citrus Peels* → Industrial D-Limonene Green Solvent
     - *200 kg Dry Rice Waste* → Biogenic Nano-Silica EV Battery Anodes
     - *40 kg Fresh Food Scraps* → 93% Black Soldier Fly Larvae (BSFL) Aquafeed

4. **Resource Journey Visualization**:
   - Interactive 5-stage milestone pipeline:
     `SOURCE` → `IDENTIFY` → `ANALYZE` → `MATCH` → `RECOMMEND`
   - Real-time animated pulse beam with clickable nodes detailing stage telemetry.

5. **"What Happens Next?" Off-Taker & Logistics Flow**:
   - **Verified Off-Takers Directory**: Browse local buyers (e.g. *VerdeBio Materials Labs*, *Cascade Mycelium*, *Pacific BioCarbon*) with capacity, buying rates, and one-click dispatch requests.
   - **Digital Circular Transfer Manifest**: Generates an official custody pass with Batch Hash (e.g. `RES-BAN-8219-F`), QR code simulation, and one-click clipboard copy / printable view.

6. **Life-Cycle Impact Ledger**:
   - Illustrative metrics (clearly labeled based on open LCA and EPA WARM models):
     - Waste Diverted (kg)
     - Potential Net CO₂e Abatement (kg)
     - Potential Value Recovered ($ USD)
     - Real-world equivalencies (car miles avoided, tree seedling years, soil amended, gallons retained).
     - Value multiplier comparison bar: ReSource vs. Standard Composting vs. Landfill Tipping Fee.

7. **Aesthetic & UX Polish**:
   - Theme: Green (`#10b981`), dark navy (`#060b14`), off-white typography (`#f8fafc`).
   - Glassmorphism, smooth animations, responsive mobile/tablet layout.
   - Web Audio API synthesizer for clean futuristic audio feedback with mute toggle.
   - Zero external runtime dependencies — runs completely offline.

---

## 🚀 Running the Prototype

### Method 1: Local HTTP Server (Built-in PowerShell Server)
Run the included PowerShell server script:
```powershell
cd C:\Users\joann\.gemini\antigravity-ide\scratch\resource-app
powershell -ExecutionPolicy Bypass -File .\server.ps1 -Port 8080
```
Open **[http://localhost:8080](http://localhost:8080)** in any browser.

### Method 2: Direct File Open
Double click `index.html` or open:
```
file:///C:/Users/joann/.gemini/antigravity-ide/scratch/resource-app/index.html
```
*Note: Thanks to the standalone universal `js/bundle.js`, the entire app works offline without CORS restrictions even when opened directly from local disk!*

---

## 📁 Project Structure

```
resource-app/
├── index.html         # Accessible HTML5 structure and modals
├── css/
│   └── style.css      # Design system, glassmorphism, responsive grids
├── js/
│   ├── bundle.js      # Universal production bundle (works on file:// and http://)
│   ├── data.js        # Empirical biochemical database & off-taker directory
│   ├── engine.js      # Multi-factor valorization ranking & impact engine
│   └── app.js         # Interactive UI controllers, audio synth & modals
├── server.ps1         # Zero-dependency PowerShell HTTP server script
└── README.md          # Project documentation & presentation guide
```
