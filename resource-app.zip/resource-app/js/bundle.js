// ==========================================================================
// ReSource - Circular Resource Intelligence Platform
// Standalone Production Bundle (Works offline & local file:// or http://)
// ==========================================================================

// --- 1. RESOURCE DATABASE ---
const RESOURCE_DATABASE = {
  "banana-peels": {
    id: "banana-peels",
    name: "Banana Peels",
    scientificName: "Musa acuminata residue",
    icon: "🍌",
    category: "Organic Fruit Residuals",
    composition: {
      cellulose: "13-17%",
      hemicellulose: "10-14%",
      lignin: "8-12%",
      pectin: "15-21%",
      potassium: "High (78 mg/g)",
      organicCarbon: "44.2%"
    },
    defaultKg: 10,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 82,
        shelfLifeHours: 48,
        description: "Intact cellular walls, active pectin chains, minimal fungal sporulation.",
        topPickRationale: "Fresh state preserves native high-molecular-weight pectin and starch matrices. This enables high-tensile bioplastic polymer casting and biodegradable film extrusion with 3.4x greater mechanical yield than decomposed matter.",
        pathways: [
          {
            id: "bp-biomaterials",
            rank: 1,
            name: "Biomaterial & Bioplastic Synthesis",
            matchPct: 94,
            badge: "Highest Economic Yield",
            tier: "Tier 1: Biochemical Valorization",
            envImpact: "-2.85 kg CO₂e / kg diverted",
            co2FactorKg: 2.85,
            valuePotential: "$4.80 / kg ($48.00 total)",
            valueFactorPerKg: 4.80,
            process: "Mild alkaline extraction followed by glycerol plasticization into compostable films and food packaging coatings.",
            offtakerType: "Biomaterial Fabrication Labs",
            processingTime: "24-48 hours",
            scalability: "High (Clean feedstock required)"
          },
          {
            id: "bp-cosmeceuticals",
            rank: 2,
            name: "Bio-Active Antioxidant & Phenol Extraction",
            matchPct: 85,
            badge: "High Value Density",
            tier: "Tier 1: High-Purity Compounds",
            envImpact: "-1.90 kg CO₂e / kg diverted",
            co2FactorKg: 1.90,
            valuePotential: "$3.50 / kg ($35.00 total)",
            valueFactorPerKg: 3.50,
            process: "Ultrasonic-assisted polyphenol (catechin & epicatechin) recovery for clean cosmetics and topical skin barrier formulations.",
            offtakerType: "Natural Cosmeceutical Brands",
            processingTime: "12-24 hours",
            scalability: "Medium"
          },
          {
            id: "bp-compost",
            rank: 3,
            name: "Potassium-Enriched Microbe Compost",
            matchPct: 78,
            badge: "Soil Regenerator",
            tier: "Tier 2: Organic Soil Vitality",
            envImpact: "-1.20 kg CO₂e / kg diverted",
            co2FactorKg: 1.20,
            valuePotential: "$0.45 / kg ($4.50 total)",
            valueFactorPerKg: 0.45,
            process: "Thermophilic aerobic composting blended with carbon-rich yard mulch, yielding ultra-high potassium humic compost.",
            offtakerType: "Regional Urban Agriculture & Nurseries",
            processingTime: "30-45 days",
            scalability: "Universal"
          },
          {
            id: "bp-feed",
            rank: 4,
            name: "Upcycled Livestock / Silage Feed",
            matchPct: 67,
            badge: "Agricultural Circularity",
            tier: "Tier 3: Feedstock Conversion",
            envImpact: "-0.95 kg CO₂e / kg diverted",
            co2FactorKg: 0.95,
            valuePotential: "$0.32 / kg ($3.20 total)",
            valueFactorPerKg: 0.32,
            process: "Thermal drying and pelletization into ruminant dietary supplement rich in trace minerals.",
            offtakerType: "Suburban Dairy & Livestock Co-ops",
            processingTime: "3-5 days",
            scalability: "High"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 91,
        shelfLifeHours: 24,
        description: "Excess free water, initial cellular breakdown, anaerobic risk if stockpiled.",
        topPickRationale: "Excess moisture hampers dry bioplastic casting but makes the biomass ideal for liquid-state anaerobic methane digestion and microalgae nutrient broth without requiring supplemental hydration.",
        pathways: [
          {
            id: "bp-biogas",
            rank: 1,
            name: "High-Caloric Anaerobic Biomethane",
            matchPct: 89,
            badge: "Renewable Energy",
            tier: "Tier 2: Clean Bioenergy",
            envImpact: "-2.10 kg CO₂e / kg diverted",
            co2FactorKg: 2.10,
            valuePotential: "$1.40 / kg equivalent",
            valueFactorPerKg: 1.40,
            process: "Co-digestion in continuous stirred-tank reactor (CSTR), generating pipeline-grade bio-CNG and liquid digestate.",
            offtakerType: "Municipal Clean Energy Digesters",
            processingTime: "15-21 days",
            scalability: "Very High"
          },
          {
            id: "bp-bsfl",
            rank: 2,
            name: "Black Soldier Fly Larvae (BSFL) Substrate",
            matchPct: 82,
            badge: "Insect Protein Upcycling",
            tier: "Tier 2: Nutrient Bio-Conversion",
            envImpact: "-1.75 kg CO₂e / kg diverted",
            co2FactorKg: 1.75,
            valuePotential: "$1.85 / kg ($18.50 total)",
            valueFactorPerKg: 1.85,
            process: "Direct inoculation into hermetia illucens bioreactors to cultivate high-protein poultry meal and frass fertilizer.",
            offtakerType: "Insect Farming & Aqua-Feed Innovators",
            processingTime: "12-14 days",
            scalability: "High"
          },
          {
            id: "bp-compost-wet",
            rank: 3,
            name: "Aerated Static Pile Compost",
            matchPct: 71,
            badge: "Soil Regenerator",
            tier: "Tier 3: Soil Nutrition",
            envImpact: "-1.10 kg CO₂e / kg diverted",
            co2FactorKg: 1.10,
            valuePotential: "$0.38 / kg ($3.80 total)",
            valueFactorPerKg: 0.38,
            process: "Blended with dry wood shavings (ratio 3:1) to balance moisture content before thermophilic composting.",
            offtakerType: "Commercial Compost Facilities",
            processingTime: "40 days",
            scalability: "High"
          },
          {
            id: "bp-biofilms-wet",
            rank: 4,
            name: "Biomaterial Synthesis (Dewatering Required)",
            matchPct: 58,
            badge: "Energy Intensive",
            tier: "Tier 1: Down-ranked (High Moisture)",
            envImpact: "-1.40 kg CO₂e / kg diverted",
            co2FactorKg: 1.40,
            valuePotential: "$2.60 / kg",
            valueFactorPerKg: 2.60,
            process: "Requires thermal mechanical dewatering step before chemical extraction, reducing net economic efficiency.",
            offtakerType: "Bio-Materials Labs",
            processingTime: "48 hours",
            scalability: "Low"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 12,
        shelfLifeHours: 720,
        description: "Dehydrated skins, stable against bacterial mold, high energy density.",
        topPickRationale: "Low moisture eliminates transportation spoilage and provides an optimal carbon scaffold for high-temperature pyrolysis into microporous activated carbon and heavy-metal water filtration sorbents.",
        pathways: [
          {
            id: "bp-activated-carbon",
            rank: 1,
            name: "Activated Bio-Carbon Water Filter Media",
            matchPct: 93,
            badge: "Engineered Environmental Tech",
            tier: "Tier 1: Technical Adsorbents",
            envImpact: "-3.10 kg CO₂e / kg diverted",
            co2FactorKg: 3.10,
            valuePotential: "$5.20 / kg ($52.00 total)",
            valueFactorPerKg: 5.20,
            process: "Slow pyrolysis at 550°C followed by CO₂ physical activation, creating high-surface-area (850 m²/g) lead/copper filter media.",
            offtakerType: "Industrial Wastewater Remediation Tech",
            processingTime: "6 hours",
            scalability: "High"
          },
          {
            id: "bp-biofuel-pellets",
            rank: 2,
            name: "Densified Bio-Pellet Clean Fuel",
            matchPct: 83,
            badge: "Fossil Fuel Displacement",
            tier: "Tier 2: Clean Heat & Power",
            envImpact: "-1.80 kg CO₂e / kg diverted",
            co2FactorKg: 1.80,
            valuePotential: "$0.85 / kg ($8.50 total)",
            valueFactorPerKg: 0.85,
            process: "Extrusion into standardized 6mm heating pellets with 16.5 MJ/kg calorific value and near-zero sulfur emissions.",
            offtakerType: "Commercial District Heating Utilities",
            processingTime: "24 hours",
            scalability: "Very High"
          },
          {
            id: "bp-flour",
            rank: 3,
            name: "Gluten-Free Functional Fiber Flour",
            matchPct: 76,
            badge: "Upcycled Nutrition",
            tier: "Tier 2: Food Grade Upcycling",
            envImpact: "-2.20 kg CO₂e / kg diverted",
            co2FactorKg: 2.20,
            valuePotential: "$3.10 / kg ($31.00 total)",
            valueFactorPerKg: 3.10,
            process: "Cryogenic milling into resistant-starch baking flour for prebiotic enriched bread mixes.",
            offtakerType: "Upcycled Food Manufacturers",
            processingTime: "12 hours",
            scalability: "Medium (Food-grade hygiene required)"
          },
          {
            id: "bp-compost-dry",
            rank: 4,
            name: "Direct Soil Conditioner Mulch",
            matchPct: 62,
            badge: "Low Tech Soil Armor",
            tier: "Tier 3: Land Application",
            envImpact: "-0.80 kg CO₂e / kg diverted",
            co2FactorKg: 0.80,
            valuePotential: "$0.30 / kg ($3.00 total)",
            valueFactorPerKg: 0.30,
            process: "Coarse shredding into water-retention orchard mulch; takes longer to break down due to dry fibrous structure.",
            offtakerType: "Berry Orchards & Vineyards",
            processingTime: "Immediate",
            scalability: "High"
          }
        ]
      }
    }
  },

  "coffee-grounds": {
    id: "coffee-grounds",
    name: "Coffee Grounds",
    scientificName: "Spent Coffee Grounds (SCG)",
    icon: "☕",
    category: "Beverage Processing Side-stream",
    composition: {
      cellulose: "8-12%",
      hemicellulose: "30-40%",
      lignin: "20-25%",
      lipidOil: "10-15%",
      nitrogen: "2.1-2.4%",
      organicCarbon: "48.9%"
    },
    defaultKg: 50,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 62,
        shelfLifeHours: 36,
        description: "Post-brewing spent grounds, aromatic, warm, rich in unoxidized coffee oils and chlorogenic acids.",
        topPickRationale: "Fresh grounds preserve volatile aromatics and delicate fatty acids without fungal rancidity, unlocking top-tier cosmeceutical and specialty textile dye extraction at premium wholesale rates.",
        pathways: [
          {
            id: "cg-cosmetics",
            rank: 1,
            name: "Supercritical Bio-Oil & Cosmeceutical Exfoliant",
            matchPct: 95,
            badge: "Highest Economic Yield",
            tier: "Tier 1: Bio-Lipid Extraction",
            envImpact: "-3.40 kg CO₂e / kg diverted",
            co2FactorKg: 3.40,
            valuePotential: "$6.20 / kg ($310.00 total)",
            valueFactorPerKg: 6.20,
            process: "CO₂ supercritical fluid extraction recovering coffee oil for luxury skincare, leaving de-oiled cake for circular composite fibers.",
            offtakerType: "Organic Skincare & Personal Care Formulators",
            processingTime: "24 hours",
            scalability: "High"
          },
          {
            id: "cg-mycelium",
            rank: 2,
            name: "Gourmet Oyster Mushroom Cultivation Substrate",
            matchPct: 88,
            badge: "High Efficiency Food Loop",
            tier: "Tier 1: Fungal Bio-Conversion",
            envImpact: "-2.60 kg CO₂e / kg diverted",
            co2FactorKg: 2.60,
            valuePotential: "$3.90 / kg mushroom yield",
            valueFactorPerKg: 3.90,
            process: "Pasteurized and blended with straw; acts as a hyper-nutritive substrate delivering 1.2 kg fresh Pleurotus ostreatus per 5 kg grounds.",
            offtakerType: "Urban Fungi AgTech Farms",
            processingTime: "18-21 days",
            scalability: "High"
          },
          {
            id: "cg-yarn",
            rank: 3,
            name: "Odor-Absorbing S.Café Circular Textile Yarn",
            matchPct: 81,
            badge: "Technical Performance Material",
            tier: "Tier 2: Technical Fibers",
            envImpact: "-2.10 kg CO₂e / kg diverted",
            co2FactorKg: 2.10,
            valuePotential: "$2.75 / kg ($137.50 total)",
            valueFactorPerKg: 2.75,
            process: "Micro-milling into sub-micron powder compounded into recycled polyester filament for odor-resistant athletic apparel.",
            offtakerType: "Sustainable Apparel Mills",
            processingTime: "48-72 hours",
            scalability: "Medium"
          },
          {
            id: "cg-compost",
            rank: 4,
            name: "Nitrogen Boost Soil Amendment",
            matchPct: 70,
            badge: "Soil Health",
            tier: "Tier 3: Regenerative Gardening",
            envImpact: "-0.90 kg CO₂e / kg diverted",
            co2FactorKg: 0.90,
            valuePotential: "$0.35 / kg ($17.50 total)",
            valueFactorPerKg: 0.35,
            process: "Aerobic microbial decomposition providing slow-release nitrogen (C:N ratio ~20:1) to combat soil compaction.",
            offtakerType: "Community Gardens & Landscapers",
            processingTime: "60 days",
            scalability: "Universal"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 78,
        shelfLifeHours: 20,
        description: "Waterlogged slurry from commercial batch brewing, vulnerable to rapid mold development.",
        topPickRationale: "Water saturation accelerates anaerobic digestion kinetics and high volatile-solids destruction, yielding dense biogas yields without pre-treatment drying penalties.",
        pathways: [
          {
            id: "cg-biogas-wet",
            rank: 1,
            name: "High-Yield Thermophilic Anaerobic Biogas",
            matchPct: 91,
            badge: "Clean Fuel Generator",
            tier: "Tier 2: Renewable Energy",
            envImpact: "-2.40 kg CO₂e / kg diverted",
            co2FactorKg: 2.40,
            valuePotential: "$1.65 / kg equivalent",
            valueFactorPerKg: 1.65,
            process: "Co-digested with municipal wastewater solids; yields 0.48 m³ biomethane per kg volatile solids.",
            offtakerType: "Regional Biogas Plants",
            processingTime: "14 days",
            scalability: "Very High"
          },
          {
            id: "cg-mycelium-wet",
            rank: 2,
            name: "Sterilized Mycelium Inoculation (Dehydrated)",
            matchPct: 79,
            badge: "Fungi Substrate",
            tier: "Tier 2: Mycelium Tech",
            envImpact: "-1.85 kg CO₂e / kg diverted",
            co2FactorKg: 1.85,
            valuePotential: "$2.80 / kg",
            valueFactorPerKg: 2.80,
            process: "Press-filtering to 55% moisture, followed by autoclave sterilization for specialty medicinal reishi / cordyceps spawn.",
            offtakerType: "Mushroom Grow Kits & Cultivators",
            processingTime: "21 days",
            scalability: "Medium"
          },
          {
            id: "cg-vermicompost",
            rank: 3,
            name: "Vermiculture Worm Casting Accelerator",
            matchPct: 74,
            badge: "Living Soil Bio-Stimulant",
            tier: "Tier 3: Soil Nutrition",
            envImpact: "-1.15 kg CO₂e / kg diverted",
            co2FactorKg: 1.15,
            valuePotential: "$0.55 / kg ($27.50 total)",
            valueFactorPerKg: 0.55,
            process: "Feeding Eisenia fetida earthworms to convert coffee grit into premium nitrogen-rich vermicompost.",
            offtakerType: "Organic Orchards & Hemp Growers",
            processingTime: "30 days",
            scalability: "Medium"
          },
          {
            id: "cg-dry-pellet-down",
            rank: 4,
            name: "Thermal Fuel Briquettes (Drying Required)",
            matchPct: 54,
            badge: "High Energy Penalty",
            tier: "Tier 3: Down-ranked (High Moisture)",
            envImpact: "-0.95 kg CO₂e / kg diverted",
            co2FactorKg: 0.95,
            valuePotential: "$0.60 / kg",
            valueFactorPerKg: 0.60,
            process: "Requires evaporative drying requiring 2.2 MJ/kg thermal input, lowering lifecycle net carbon benefit.",
            offtakerType: "Biomass Heating Plants",
            processingTime: "36 hours",
            scalability: "Low"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 8,
        shelfLifeHours: 1440,
        description: "Thermally or solar dried, loose granular form, indefinite shelf stability when sealed.",
        topPickRationale: "Sub-10% moisture enables direct compounding into bio-composite resins and precision 3D-printing filament with zero degassing bubbles or thermal hydrolysis defects.",
        pathways: [
          {
            id: "cg-biocomposites",
            rank: 1,
            name: "Circular Bio-Composite Polymer (Coffee-PLA)",
            matchPct: 96,
            badge: "Highest Economic Yield",
            tier: "Tier 1: Advanced Materials",
            envImpact: "-3.80 kg CO₂e / kg diverted",
            co2FactorKg: 3.80,
            valuePotential: "$7.50 / kg ($375.00 total)",
            valueFactorPerKg: 7.50,
            process: "Twin-screw compounding with polylactic acid (40% SCG fill) producing injection-molding pellets for reusable drinkware and eyeglass frames.",
            offtakerType: "Sustainable Polymers & Injection Molders",
            processingTime: "24 hours",
            scalability: "High"
          },
          {
            id: "cg-fuel-logs",
            rank: 2,
            name: "Zero-Smoke High-Btu Eco Fireplace Logs",
            matchPct: 86,
            badge: "Clean Heat Energy",
            tier: "Tier 2: Renewable Biomass",
            envImpact: "-2.05 kg CO₂e / kg diverted",
            co2FactorKg: 2.05,
            valuePotential: "$1.20 / kg ($60.00 total)",
            valueFactorPerKg: 1.20,
            process: "High-pressure hydraulic compaction with natural wax binder, burning 20% hotter and longer than kiln-dried oak wood.",
            offtakerType: "Eco-Home & Heating Retailers",
            processingTime: "8 hours",
            scalability: "Very High"
          },
          {
            id: "cg-adsorbent",
            rank: 3,
            name: "H₂S Gas Scrubbing Bio-Char Adsorbent",
            matchPct: 82,
            badge: "Industrial Air Purification",
            tier: "Tier 2: Environmental Remediation",
            envImpact: "-2.40 kg CO₂e / kg diverted",
            co2FactorKg: 2.40,
            valuePotential: "$3.80 / kg ($190.00 total)",
            valueFactorPerKg: 3.80,
            process: "Nitrogen-purged fast pyrolysis producing high-surface meso-porous char for sewer and sewage gas odor capture.",
            offtakerType: "Wastewater Treatment Authorities",
            processingTime: "12 hours",
            scalability: "Medium"
          },
          {
            id: "cg-soil-dry",
            rank: 4,
            name: "Direct Soil Slug Barrier & Top Dressing",
            matchPct: 65,
            badge: "Natural Pest Deterrent",
            tier: "Tier 3: Garden Mulch",
            envImpact: "-0.75 kg CO₂e / kg diverted",
            co2FactorKg: 0.75,
            valuePotential: "$0.30 / kg ($15.00 total)",
            valueFactorPerKg: 0.30,
            process: "Surface broadcasting around garden perimeters to deter snails/slugs via residual caffeine toxicity.",
            offtakerType: "Urban Landscapers & Garden Centers",
            processingTime: "Immediate",
            scalability: "Universal"
          }
        ]
      }
    }
  },

  "coconut-husk": {
    id: "coconut-husk",
    name: "Coconut Husk",
    scientificName: "Cocos nucifera mesocarp & coir",
    icon: "🥥",
    category: "Lignocellulosic Fiber Waste",
    composition: {
      lignin: "41-45% (Extremely High)",
      cellulose: "36-43%",
      hemicellulose: "0.25-0.5%",
      ashContent: "2-4%",
      carbonContent: "51.2%"
    },
    defaultKg: 100,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 55,
        shelfLifeHours: 240,
        description: "Green/young husk, resilient long fibers embedded in moisture-retaining pith.",
        topPickRationale: "Fresh coir fibers retain high flexural elasticity and natural moisture-wicking capillary channels, making them the #1 choice for high-durability hydro-seeding mats and erosion control geomesh.",
        pathways: [
          {
            id: "ch-erosion-mats",
            rank: 1,
            name: "Biodegradable Coir Geotextile & Erosion Blankets",
            matchPct: 93,
            badge: "Civil Infrastructure & Restoration",
            tier: "Tier 1: Engineering Geotextiles",
            envImpact: "-3.60 kg CO₂e / kg diverted",
            co2FactorKg: 3.60,
            valuePotential: "$4.10 / kg ($410.00 total)",
            valueFactorPerKg: 4.10,
            process: "Mechanical decortication into long coir yarn spun into heavy-duty woven mesh for riverbank stabilization and highway revegetation.",
            offtakerType: "Civil Environmental Contractors",
            processingTime: "48 hours",
            scalability: "High"
          },
          {
            id: "ch-horticultural-pith",
            rank: 2,
            name: "Peat-Free Hydroponic Growing Media (Coco Coir)",
            matchPct: 87,
            badge: "Peatland Preservation",
            tier: "Tier 1: Eco-Horticulture",
            envImpact: "-2.90 kg CO₂e / kg diverted",
            co2FactorKg: 2.90,
            valuePotential: "$2.85 / kg ($285.00 total)",
            valueFactorPerKg: 2.85,
            process: "Washing and buffering with calcium nitrate to remove residual ocean sodium, compressed into expandable greenhouse blocks.",
            offtakerType: "Commercial Greenhouse & Vertical Farms",
            processingTime: "36 hours",
            scalability: "Very High"
          },
          {
            id: "ch-acoustic-panels",
            rank: 3,
            name: "Architectural Acoustic Damping Panels",
            matchPct: 79,
            badge: "Green Building Interior",
            tier: "Tier 2: Circular Construction",
            envImpact: "-2.10 kg CO₂e / kg diverted",
            co2FactorKg: 2.10,
            valuePotential: "$3.40 / kg ($340.00 total)",
            valueFactorPerKg: 3.40,
            process: "Hot-pressing chopped fibers with natural lignin binder into Class-A NRC acoustic tiles for eco-offices.",
            offtakerType: "Sustainable Architecture Fabricators",
            processingTime: "3 days",
            scalability: "Medium"
          },
          {
            id: "ch-fuel-fresh",
            rank: 4,
            name: "Industrial Boiler Biomass",
            matchPct: 61,
            badge: "Thermal Energy",
            tier: "Tier 3: Low-Tier Thermal",
            envImpact: "-0.90 kg CO₂e / kg diverted",
            co2FactorKg: 0.90,
            valuePotential: "$0.40 / kg ($40.00 total)",
            valueFactorPerKg: 0.40,
            process: "Direct co-firing in high-capacity industrial biomass boilers; lower efficiency due to 55% moisture burden.",
            offtakerType: "Local Industrial Plants",
            processingTime: "Immediate",
            scalability: "High"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 75,
        shelfLifeHours: 120,
        description: "Water-soaked husk after maritime transport or monsoon storage, heavy and flexible.",
        topPickRationale: "Water-softened husks drastically reduce decortication energy by 60%, making mechanical fiber pulping and enzymatic retting for automotive trunk lining and mattress padding exceptionally cost-effective.",
        pathways: [
          {
            id: "ch-auto-composites",
            rank: 1,
            name: "Enzyme-Retted Automotive Structural Composites",
            matchPct: 90,
            badge: "Automotive Circularity",
            tier: "Tier 1: Industrial Fiber",
            envImpact: "-3.20 kg CO₂e / kg diverted",
            co2FactorKg: 3.20,
            valuePotential: "$3.70 / kg ($370.00 total)",
            valueFactorPerKg: 3.70,
            process: "Water retting accelerates lignin loosening; fibers are needle-punched with polypropylene for lightweight automotive door panels.",
            offtakerType: "Tier-1 Automotive Component Suppliers",
            processingTime: "5-7 days",
            scalability: "High"
          },
          {
            id: "ch-coco-pith-wet",
            rank: 2,
            name: "Wet Desalinated Hydroponic Slurry",
            matchPct: 83,
            badge: "Hydroponics Substrate",
            tier: "Tier 2: Agricultural Growing",
            envImpact: "-2.30 kg CO₂e / kg diverted",
            co2FactorKg: 2.30,
            valuePotential: "$2.10 / kg ($210.00 total)",
            valueFactorPerKg: 2.10,
            process: "Washed in wet retention basins to displace salts, then dispatched locally as live seedling medium.",
            offtakerType: "Regional Horticulture Greenhouses",
            processingTime: "48 hours",
            scalability: "High"
          },
          {
            id: "ch-compost-bulking",
            rank: 3,
            name: "Municipal Compost Bulking & Aeration Agent",
            matchPct: 73,
            badge: "Aeration Matrix",
            tier: "Tier 3: Waste Management",
            envImpact: "-1.05 kg CO₂e / kg diverted",
            co2FactorKg: 1.05,
            valuePotential: "$0.30 / kg ($30.00 total)",
            valueFactorPerKg: 0.30,
            process: "Coarsely shredded to prevent compaction in high-sludge municipal composting windrows.",
            offtakerType: "Municipal Solid Waste Composting",
            processingTime: "90 days",
            scalability: "Universal"
          },
          {
            id: "ch-char-wet",
            rank: 4,
            name: "Pyrolysis Biochar (High Dewatering Cost)",
            matchPct: 56,
            badge: "Energy Inefficient",
            tier: "Tier 3: Down-ranked (High Moisture)",
            envImpact: "-1.10 kg CO₂e / kg diverted",
            co2FactorKg: 1.10,
            valuePotential: "$1.20 / kg",
            valueFactorPerKg: 1.20,
            process: "Requires massive drying energy before pyrolysis retorts can ignite, cutting net returns.",
            offtakerType: "Biochar Producers",
            processingTime: "4 days",
            scalability: "Low"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 10,
        shelfLifeHours: 8760,
        description: "Sun-cured brown husks, extremely rigid, >42% dense lignin content, near-infinite storage life.",
        topPickRationale: "Ultra-dry dense lignin structure is the world's finest feedstock for ultra-hard activated bio-char, capable of recovering precious gold/lithium in hydrometallurgy and sequestering recalcitrant carbon for 500+ years.",
        pathways: [
          {
            id: "ch-metallurgical-carbon",
            rank: 1,
            name: "High-Hardness Activated Carbon (Precious Metal & PFAS Recovery)",
            matchPct: 97,
            badge: "Critical Minerals & Clean Water",
            tier: "Tier 1: High-Tech Advanced Carbon",
            envImpact: "-4.50 kg CO₂e / kg diverted (500-yr durable sequestration)",
            co2FactorKg: 4.50,
            valuePotential: "$6.80 / kg ($680.00 total)",
            valueFactorPerKg: 6.80,
            process: "Pyrolysis at 800°C with steam activation; yields ultra-abrasion-resistant microporous carbon with iodine number >1100 mg/g.",
            offtakerType: "Advanced Water Tech & Battery Mineral Recyclers",
            processingTime: "12 hours",
            scalability: "Very High"
          },
          {
            id: "ch-ecoboards",
            rank: 2,
            name: "Binderless Eco-Structural Timber (Formaldehyde-Free)",
            matchPct: 89,
            badge: "Zero-VOC Construction",
            tier: "Tier 1: Circular Building Materials",
            envImpact: "-3.10 kg CO₂e / kg diverted",
            co2FactorKg: 3.10,
            valuePotential: "$4.20 / kg ($420.00 total)",
            valueFactorPerKg: 4.20,
            process: "Thermal hot-pressing (190°C) where the husk's own natural lignin melts and binds fibers into waterproof construction boards without synthetic glue.",
            offtakerType: "Modular Green Home Manufacturers",
            processingTime: "24 hours",
            scalability: "High"
          },
          {
            id: "ch-bio-char-soil",
            rank: 3,
            name: "Permanently Sequestered Agricultural Biochar",
            matchPct: 84,
            badge: "Carbon Removal Credits (CORCs)",
            tier: "Tier 2: Carbon Dioxide Removal",
            envImpact: "-2.80 kg CO₂e / kg diverted",
            co2FactorKg: 2.80,
            valuePotential: "$2.50 / kg + $120/t Carbon Credit",
            valueFactorPerKg: 2.50,
            process: "Slow pyrolysis producing permanent soil recalcitrant carbon, boosting moisture retention in drought-stricken soils.",
            offtakerType: "Puro.earth Registered Carbon Removal Projects",
            processingTime: "8 hours",
            scalability: "Very High"
          },
          {
            id: "ch-briquette-dry",
            rank: 4,
            name: "Smokeless Coconut Charcoal Briquettes",
            matchPct: 75,
            badge: "Clean Cooking Fuel",
            tier: "Tier 3: Clean Household Heat",
            envImpact: "-1.50 kg CO₂e / kg diverted",
            co2FactorKg: 1.50,
            valuePotential: "$1.10 / kg ($110.00 total)",
            valueFactorPerKg: 1.10,
            process: "Milled charcoal extruded with tapioca starch binder into long-burning, ash-free culinary cooking fuel.",
            offtakerType: "Culinary & Commercial Charcoal Distributors",
            processingTime: "16 hours",
            scalability: "High"
          }
        ]
      }
    }
  },

  "rice-waste": {
    id: "rice-waste",
    name: "Rice Waste",
    scientificName: "Oryza sativa straw & husks",
    icon: "🌾",
    category: "Grain Milling Byproduct",
    composition: {
      silica: "15-20% Amorphous SiO₂",
      cellulose: "35-40%",
      hemicellulose: "20-25%",
      lignin: "12-16%",
      organicCarbon: "41.8%"
    },
    defaultKg: 200,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 35,
        shelfLifeHours: 120,
        description: "Recently harvested straw/chaff, pliable stems with high amorphous biogenic silica.",
        topPickRationale: "Fresh straw retains intact long cellulose fibers that can be bleached and pressed without harsh sulfur chemicals into biodegradable food takeout packaging and molded straw pulp trays.",
        pathways: [
          {
            id: "rw-molded-packaging",
            rank: 1,
            name: "Molded Fiber Food Containers & Biodegradable Straws",
            matchPct: 92,
            badge: "Single-Use Plastic Alternative",
            tier: "Tier 1: Bio-Packaging",
            envImpact: "-2.95 kg CO₂e / kg diverted",
            co2FactorKg: 2.95,
            valuePotential: "$3.80 / kg ($760.00 total)",
            valueFactorPerKg: 3.80,
            process: "Mechanical thermo-mechanical pulping pressed into PFAS-free, microwaveable compostable takeout clamshells.",
            offtakerType: "Sustainable Food Packaging Brands",
            processingTime: "24 hours",
            scalability: "High"
          },
          {
            id: "rw-myco-insulation",
            rank: 2,
            name: "Mycelium Thermal Insulation Blocks",
            matchPct: 86,
            badge: "Passive House Construction",
            tier: "Tier 1: Green Building Insulation",
            envImpact: "-2.40 kg CO₂e / kg diverted",
            co2FactorKg: 2.40,
            valuePotential: "$2.90 / kg ($580.00 total)",
            valueFactorPerKg: 2.90,
            process: "Inoculated with fungal mycelium growing through chopped straw to create fire-resistant, non-toxic acoustic and wall insulation batts.",
            offtakerType: "Eco-Insulation Manufacturers",
            processingTime: "10-14 days",
            scalability: "Medium"
          },
          {
            id: "rw-silica-fresh",
            rank: 3,
            name: "Biogenic Nano-Silica for Low-Carbon Cement",
            matchPct: 80,
            badge: "Concrete Decarbonization",
            tier: "Tier 2: Supplementary Cementitious",
            envImpact: "-2.10 kg CO₂e / kg diverted",
            co2FactorKg: 2.10,
            valuePotential: "$1.80 / kg ($360.00 total)",
            valueFactorPerKg: 1.80,
            process: "Controlled combustion ash utilized as high-reactivity pozzolan replacing 20% of carbon-intensive Portland cement.",
            offtakerType: "Green Ready-Mix Concrete Plants",
            processingTime: "48 hours",
            scalability: "Very High"
          },
          {
            id: "rw-animal-silage",
            rank: 4,
            name: "Urea-Treated Ruminant Silage Feed",
            matchPct: 69,
            badge: "Feed Upcycling",
            tier: "Tier 3: Livestock Agriculture",
            envImpact: "-0.85 kg CO₂e / kg diverted",
            co2FactorKg: 0.85,
            valuePotential: "$0.28 / kg ($56.00 total)",
            valueFactorPerKg: 0.28,
            process: "Ammoniation treatment to break down silica wax coating and elevate digestible crude protein from 3% to 8%.",
            offtakerType: "Regional Cattle & Goat Farms",
            processingTime: "21 days",
            scalability: "High"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 65,
        shelfLifeHours: 48,
        description: "Rain-soaked post-harvest straw, prone to spontaneous heating and methane-emitting field decomposition.",
        topPickRationale: "Wet straw naturally softens lignified cell walls, drastically speeding up cellulolytic enzyme penetration for second-generation bio-ethanol fermentation and fungal fruiting.",
        pathways: [
          {
            id: "rw-straw-mushroom",
            rank: 1,
            name: "Volvariella Volvacea (Paddy Straw Mushroom) Cultivation",
            matchPct: 91,
            badge: "High Turnover Food Yield",
            tier: "Tier 1: Commercial Mycology",
            envImpact: "-2.60 kg CO₂e / kg diverted",
            co2FactorKg: 2.60,
            valuePotential: "$4.20 / kg mushroom harvest",
            valueFactorPerKg: 4.20,
            process: "Direct layered composting beds yielding rapid mushroom flushes within just 10-12 days at high ambient humidity.",
            offtakerType: "Specialty Fungi Growers",
            processingTime: "12 days",
            scalability: "High"
          },
          {
            id: "rw-cellulosic-ethanol",
            rank: 2,
            name: "2G Cellulosic Bio-Ethanol Fuel",
            matchPct: 83,
            badge: "Advanced Clean Aviation / Bio-Fuel",
            tier: "Tier 2: Clean Bioenergy",
            envImpact: "-2.20 kg CO₂e / kg diverted",
            co2FactorKg: 2.20,
            valuePotential: "$1.40 / kg equivalent",
            valueFactorPerKg: 1.40,
            process: "Steam explosion pretreatment and enzymatic hydrolysis converting hemicellulose sugars into low-carbon bioethanol.",
            offtakerType: "Advanced Bio-Refineries",
            processingTime: "72 hours",
            scalability: "Very High"
          },
          {
            id: "rw-anaerobic-wet",
            rank: 3,
            name: "Co-Digestion with Dairy Manure for Biogas",
            matchPct: 76,
            badge: "Farm Microgrid Energy",
            tier: "Tier 2: Farm Clean Energy",
            envImpact: "-1.70 kg CO₂e / kg diverted",
            co2FactorKg: 1.70,
            valuePotential: "$0.90 / kg equivalent",
            valueFactorPerKg: 0.90,
            process: "Balances the C:N ratio of nitrogen-heavy dairy liquid waste inside farm plug-flow digesters.",
            offtakerType: "Dairy Farm Biogas Cooperatives",
            processingTime: "30 days",
            scalability: "High"
          },
          {
            id: "rw-direct-plow",
            rank: 4,
            name: "Direct Soil Incorporation (Methane Risk)",
            matchPct: 48,
            badge: "Low Value / High Methane",
            tier: "Tier 3: Suboptimal Conventional Practice",
            envImpact: "+0.40 kg CO₂e / kg (Methane penalty)",
            co2FactorKg: -0.40,
            valuePotential: "$0.05 / kg",
            valueFactorPerKg: 0.05,
            process: "Plowing wet straw into submerged paddies generates anaerobic methane plumes; strongly discouraged by LCA metrics.",
            offtakerType: "Traditional Agriculture",
            processingTime: "Immediate",
            scalability: "High"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 9,
        shelfLifeHours: 4320,
        description: "Dry milled rice husk (hull), high silica shell, abrasive, highly combustible.",
        topPickRationale: "Pure dry rice husks contain up to 20% non-crystalline biogenic silica. Controlled thermal combustion produces high-purity amorphous nanosilica used in lithium battery anode binders and green cement pozzolans.",
        pathways: [
          {
            id: "rw-battery-silica",
            rank: 1,
            name: "Biogenic Nano-Silica for EV Battery Anodes & Green Cement",
            matchPct: 95,
            badge: "Next-Gen Clean Energy Tech",
            tier: "Tier 1: High-Purity Technical Materials",
            envImpact: "-4.10 kg CO₂e / kg diverted",
            co2FactorKg: 4.10,
            valuePotential: "$5.60 / kg ($1,120.00 total)",
            valueFactorPerKg: 5.60,
            process: "Fluidized bed gasification at 700°C generating clean electric power while recovering 99.2% pure white amorphous silica powder.",
            offtakerType: "Battery Materials Startups & Nano-Silica Buyers",
            processingTime: "12 hours",
            scalability: "High"
          },
          {
            id: "rw-silica-ash-brick",
            rank: 2,
            name: "Ultra-Lightweight Pozzolanic Bio-Bricks",
            matchPct: 88,
            badge: "Embodied Carbon Reducer",
            tier: "Tier 1: Low-Carbon Construction",
            envImpact: "-2.80 kg CO₂e / kg diverted",
            co2FactorKg: 2.80,
            valuePotential: "$2.40 / kg ($480.00 total)",
            valueFactorPerKg: 2.40,
            process: "Alkaline geopolymer activation turning ash and husk matrix into kiln-free compressed masonry blocks with 3x higher thermal insulation.",
            offtakerType: "Circular Construction Startups",
            processingTime: "48 hours",
            scalability: "Very High"
          },
          {
            id: "rw-hydroponic-char",
            rank: 3,
            name: "Carbonized Rice Husk (CRH) Root Aerator",
            matchPct: 82,
            badge: "Root Zone Vitality",
            tier: "Tier 2: Agro-Tech Substrate",
            envImpact: "-1.90 kg CO₂e / kg diverted",
            co2FactorKg: 1.90,
            valuePotential: "$1.75 / kg ($350.00 total)",
            valueFactorPerKg: 1.75,
            process: "Incomplete combustion yields sterile, silica-reinforced carbon granules that maximize oxygen delivery in soilless nursery culture.",
            offtakerType: "Commercial Hydroponic Nurseries",
            processingTime: "6 hours",
            scalability: "High"
          },
          {
            id: "rw-power-pellets",
            rank: 4,
            name: "Direct Biomass Power Generation",
            matchPct: 73,
            badge: "Grid Power Offset",
            tier: "Tier 3: Grid Energy",
            envImpact: "-1.30 kg CO₂e / kg diverted",
            co2FactorKg: 1.30,
            valuePotential: "$0.65 / kg ($130.00 total)",
            valueFactorPerKg: 0.65,
            process: "Co-fired in dedicated biomass power plants to supply baseload regional renewable electricity.",
            offtakerType: "Renewable Energy Independent Power Producers",
            processingTime: "Immediate",
            scalability: "Very High"
          }
        ]
      }
    }
  },

  "citrus-peels": {
    id: "citrus-peels",
    name: "Citrus Peels",
    scientificName: "Citrus aurantium / sinensis flavedo & albedo",
    icon: "🍊",
    category: "Specialty High-Terpene Fruit Stream",
    composition: {
      pectin: "20-30% High-Methoxyl",
      essentialOils: "2-4% (90%+ D-Limonene)",
      cellulose: "12-16%",
      hemicellulose: "10-15%",
      flavonoids: "Hesperidin & Naringin"
    },
    defaultKg: 25,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 80,
        shelfLifeHours: 40,
        description: "Freshly squeezed juicing residues, bursting with volatile essential oils and unhydrolyzed pectin.",
        topPickRationale: "Fresh peel oil glands remain fully pressurized and unoxidized. Steam distillation yields pharmaceutical/industrial grade D-Limonene (a non-toxic petrochemical solvent replacement) and premium high-ester pectin.",
        pathways: [
          {
            id: "cp-limonene-solvent",
            rank: 1,
            name: "D-Limonene Green Bio-Solvent & Degreaser",
            matchPct: 96,
            badge: "Highest Economic Yield",
            tier: "Tier 1: Bio-Chemical Solvents",
            envImpact: "-3.90 kg CO₂e / kg diverted (displaces petroleum solvents)",
            co2FactorKg: 3.90,
            valuePotential: "$7.20 / kg ($180.00 total)",
            valueFactorPerKg: 7.20,
            process: "Fractional cold-pressing and vacuum distillation isolating 95% pure terpene hydrocarbon replacing toxic acetone and mineral spirits.",
            offtakerType: "Industrial Green Cleaning & Precision Aerospace Solvents",
            processingTime: "18 hours",
            scalability: "High"
          },
          {
            id: "cp-pectin-food",
            rank: 2,
            name: "High-Methoxyl Pectin Food Stabilizer",
            matchPct: 89,
            badge: "Clean-Label Food Tech",
            tier: "Tier 1: Food-Grade Gelling Agents",
            envImpact: "-2.80 kg CO₂e / kg diverted",
            co2FactorKg: 2.80,
            valuePotential: "$4.50 / kg ($112.50 total)",
            valueFactorPerKg: 4.50,
            process: "Hot acid/enzymatic extraction of white albedo pith, precipitated with ethanol into high-performance vegan gelling agent.",
            offtakerType: "Confectionery, Jam, and Plant-Dairy Brands",
            processingTime: "36 hours",
            scalability: "High"
          },
          {
            id: "cp-citrus-leather",
            rank: 3,
            name: "Next-Gen Biomaterial 'Citrus Leather'",
            matchPct: 79,
            badge: "Cruelty-Free Circular Fashion",
            tier: "Tier 2: Upcycled Biomaterials",
            envImpact: "-3.10 kg CO₂e / kg diverted",
            co2FactorKg: 3.10,
            valuePotential: "$5.80 / kg equivalent",
            valueFactorPerKg: 5.80,
            process: "Cellulose microfiber blending with organic polyurethane binders into supple leather alternative for luxury accessories.",
            offtakerType: "Sustainable Fashion & Automotive Interiors",
            processingTime: "5 days",
            scalability: "Medium"
          },
          {
            id: "cp-compost-fresh",
            rank: 4,
            name: "pH-Balanced Vermicompost (Requires Dilution)",
            matchPct: 59,
            badge: "Sensitive Acidity",
            tier: "Tier 3: Diluted Composting",
            envImpact: "-0.80 kg CO₂e / kg diverted",
            co2FactorKg: 0.80,
            valuePotential: "$0.30 / kg ($7.50 total)",
            valueFactorPerKg: 0.30,
            process: "High acidity and antibacterial limonene inhibit earthworms unless pre-aerated and diluted 10:1 with high-carbon mulch.",
            offtakerType: "Commercial Compost Yards",
            processingTime: "60 days",
            scalability: "Medium"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 88,
        shelfLifeHours: 24,
        description: "Juice processing sludge, high acidity, waterlogged pulp.",
        topPickRationale: "High soluble sugar content in wet pulp allows rapid microalgae feed or bio-flavonoid isolation while preserving the water phase for industrial citric acid bio-fermentation.",
        pathways: [
          {
            id: "cp-citric-acid",
            rank: 1,
            name: "Aspergillus Niger Citric Acid Fermentation",
            matchPct: 88,
            badge: "Natural Preservative",
            tier: "Tier 2: Biochemical Synthesis",
            envImpact: "-2.30 kg CO₂e / kg diverted",
            co2FactorKg: 2.30,
            valuePotential: "$2.90 / kg ($72.50 total)",
            valueFactorPerKg: 2.90,
            process: "Submerged aerobic fermentation by fungal cultures converting free hexose sugars directly into food-grade citric acid.",
            offtakerType: "Beverage & Food Processing Plants",
            processingTime: "5-6 days",
            scalability: "High"
          },
          {
            id: "cp-flavonoid-extract",
            rank: 2,
            name: "Hesperidin Nutraceutical Extraction",
            matchPct: 82,
            badge: "Cardiovascular Health",
            tier: "Tier 1: High-Purity Nutraceuticals",
            envImpact: "-2.10 kg CO₂e / kg diverted",
            co2FactorKg: 2.10,
            valuePotential: "$4.10 / kg ($102.50 total)",
            valueFactorPerKg: 4.10,
            process: "Alkaline dissolution and acid crystallization recovering high-potency bioflavonoids for dietary supplement capsules.",
            offtakerType: "Nutraceutical Manufacturing Labs",
            processingTime: "48 hours",
            scalability: "Medium"
          },
          {
            id: "cp-biogas-wet",
            rank: 3,
            name: "Controlled Anaerobic Digestion (Anti-microbial Monitored)",
            matchPct: 71,
            badge: "Clean Fuel",
            tier: "Tier 2: Bioenergy",
            envImpact: "-1.60 kg CO₂e / kg diverted",
            co2FactorKg: 1.60,
            valuePotential: "$1.10 / kg equivalent",
            valueFactorPerKg: 1.10,
            process: "Strict dosing control required to ensure D-limonene concentrations stay below 400 mg/L to avoid killing methanogenic bacteria.",
            offtakerType: "Municipal Clean Energy Digesters",
            processingTime: "25 days",
            scalability: "Medium"
          },
          {
            id: "cp-direct-dump",
            rank: 4,
            name: "Unmanaged Agricultural Spreading",
            matchPct: 42,
            badge: "High Soil Acidification",
            tier: "Tier 3: Suboptimal Practice",
            envImpact: "+0.20 kg CO₂e / kg",
            co2FactorKg: -0.20,
            valuePotential: "$0.05 / kg",
            valueFactorPerKg: 0.05,
            process: "Direct dumping risks soil microbial shock and acid runoff into groundwater tables.",
            offtakerType: "None recommended",
            processingTime: "Immediate",
            scalability: "Low"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 11,
        shelfLifeHours: 2160,
        description: "Dehydrated orange/lemon rinds, brittle, fragrant, stable against mold.",
        topPickRationale: "Dehydrated citrus rinds have volatile solvents stabilized; the dry pectin-cellulose matrix forms extraordinary heavy-metal biosorption beads and aromatic antimicrobial bio-pellets.",
        pathways: [
          {
            id: "cp-biosorption-beads",
            rank: 1,
            name: "Heavy Metal Water Biosorption Media (Lead/Cadmium Filter)",
            matchPct: 94,
            badge: "Clean Water Innovation",
            tier: "Tier 1: Eco-Adsorbents",
            envImpact: "-3.50 kg CO₂e / kg diverted",
            co2FactorKg: 3.50,
            valuePotential: "$5.40 / kg ($135.00 total)",
            valueFactorPerKg: 5.40,
            process: "Cross-linking dry citrus pectin matrix with calcium chloride to form granular biosorbent beads with 98.4% lead ion chelation capacity.",
            offtakerType: "Mining & Industrial Effluent Treatment",
            processingTime: "12 hours",
            scalability: "High"
          },
          {
            id: "cp-botanical-tea",
            rank: 2,
            name: "Culinary & Botanical Infusion Flakes",
            matchPct: 86,
            badge: "Upcycled Gastronomy",
            tier: "Tier 1: Food Ingredient Upcycling",
            envImpact: "-2.20 kg CO₂e / kg diverted",
            co2FactorKg: 2.20,
            valuePotential: "$4.90 / kg ($122.50 total)",
            valueFactorPerKg: 4.90,
            process: "Precision sizing and metal detection sorting for herbal tea blenders and craft craft brewing aromatics.",
            offtakerType: "Specialty Tea & Craft Breweries",
            processingTime: "6 hours",
            scalability: "Medium (Organic certified batches)"
          },
          {
            id: "cp-odor-pellets",
            rank: 3,
            name: "Antimicrobial Pet Litter & Deodorizer Pellets",
            matchPct: 81,
            badge: "Natural Pet Care",
            tier: "Tier 2: Consumer Upcycled Goods",
            envImpact: "-1.80 kg CO₂e / kg diverted",
            co2FactorKg: 1.80,
            valuePotential: "$2.60 / kg ($65.00 total)",
            valueFactorPerKg: 2.60,
            process: "Pelletized with bentonite clay; naturally suppresses bacterial ammonia synthesis via endogenous citrus terpenes.",
            offtakerType: "Eco-Pet Product Manufacturers",
            processingTime: "18 hours",
            scalability: "High"
          },
          {
            id: "cp-potpourri",
            rank: 4,
            name: "Aromatic Firestarter & Natural Kindling",
            matchPct: 70,
            badge: "Clean Burning Household",
            tier: "Tier 3: Consumer Heating",
            envImpact: "-1.10 kg CO₂e / kg diverted",
            co2FactorKg: 1.10,
            valuePotential: "$1.20 / kg ($30.00 total)",
            valueFactorPerKg: 1.20,
            process: "Natural resin-infused firestarter cones that burn with a clean citrus scent.",
            offtakerType: "Outdoor & Fireplace Retailers",
            processingTime: "8 hours",
            scalability: "High"
          }
        ]
      }
    }
  },

  "food-scraps": {
    id: "food-scraps",
    name: "Food Scraps",
    scientificName: "Mixed Post-Consumer & Pre-Consumer Organics",
    icon: "🥗",
    category: "Heterogeneous Organic Waste",
    composition: {
      organicMatter: "85-92%",
      moisture: "70-85%",
      cNRatio: "15:1 - 25:1",
      lipids: "5-10%",
      protein: "10-18%"
    },
    defaultKg: 40,
    conditions: {
      fresh: {
        label: "Fresh",
        moisturePct: 78,
        shelfLifeHours: 24,
        description: "Kitchen prep trims, salad leaves, bakery trimmings; free of mold or putrefaction odors.",
        topPickRationale: "Fresh mixed scraps boast intact fats, proteins, and carbohydrates ideal for high-density Black Soldier Fly Larvae (BSFL) insect bioconversion, turning waste into sustainable protein 20x faster than traditional composting.",
        pathways: [
          {
            id: "fs-bsfl-protein",
            rank: 1,
            name: "Black Soldier Fly Larvae (BSFL) Sustainable Aquafeed",
            matchPct: 93,
            badge: "Highest Circular Velocity",
            tier: "Tier 1: Bio-Protein Agriculture",
            envImpact: "-3.20 kg CO₂e / kg diverted (displaces wild fishmeal)",
            co2FactorKg: 3.20,
            valuePotential: "$3.40 / kg ($136.00 total)",
            valueFactorPerKg: 3.40,
            process: "Inoculation into climate-controlled insect bioreactors; larvae consume 2x their bodyweight daily, yielding 42% protein meal and chitin.",
            offtakerType: "Sustainable Aquafeed & Poultry Tech Ventures",
            processingTime: "10-12 days",
            scalability: "Very High"
          },
          {
            id: "fs-bokashi-ferment",
            rank: 2,
            name: "Anaerobic Bokashi Micro-Fermentation Concentrate",
            matchPct: 86,
            badge: "Odorless Microbial Probiotics",
            tier: "Tier 1: Regenerative Soil Science",
            envImpact: "-2.40 kg CO₂e / kg diverted",
            co2FactorKg: 2.40,
            valuePotential: "$2.10 / kg ($84.00 total)",
            valueFactorPerKg: 2.10,
            process: "Inoculated with Effective Microorganisms (EM-1: lactic acid bacteria & yeasts) fermenting scraps without greenhouse gas venting.",
            offtakerType: "Urban Soil Cooperatives & Market Gardeners",
            processingTime: "14 days",
            scalability: "High"
          },
          {
            id: "fs-hot-compost",
            rank: 3,
            name: "Thermophilic Living Soil Humus",
            matchPct: 79,
            badge: "Soil Carbon Enrichment",
            tier: "Tier 2: Municipal Circular Soil",
            envImpact: "-1.45 kg CO₂e / kg diverted",
            co2FactorKg: 1.45,
            valuePotential: "$0.50 / kg ($20.00 total)",
            valueFactorPerKg: 0.50,
            process: "Engineered windrow composting reaching 65°C to pasteurize weed seeds and pathogens, creating dark bio-active humus.",
            offtakerType: "Municipal Composting & Regenerative Farms",
            processingTime: "45-60 days",
            scalability: "Universal"
          },
          {
            id: "fs-anaerobic-power",
            rank: 4,
            name: "Municipal Biomethane Grid Injection",
            matchPct: 72,
            badge: "Clean City Energy",
            tier: "Tier 2: Clean Bioenergy",
            envImpact: "-1.80 kg CO₂e / kg diverted",
            co2FactorKg: 1.80,
            valuePotential: "$0.95 / kg equivalent",
            valueFactorPerKg: 0.95,
            process: "High-solids anaerobic digestion creating renewable natural gas (RNG) powering city transit fleets.",
            offtakerType: "City Public Works & Gas Utilities",
            processingTime: "21 days",
            scalability: "Very High"
          }
        ]
      },
      wet: {
        label: "Wet",
        moisturePct: 89,
        shelfLifeHours: 12,
        description: "Post-consumer plate scrapings, soup stocks, dairy residues; slurry consistency.",
        topPickRationale: "Wet organic slurries bypass pulping and hydro-cyclone dilution stages, feeding directly into thermophilic anaerobic digestion systems to capture maximum volatile fatty acids and methane.",
        pathways: [
          {
            id: "fs-biomethane-wet",
            rank: 1,
            name: "High-Rate Anaerobic Digestion & Bio-Methane",
            matchPct: 92,
            badge: "Zero-Waste Power",
            tier: "Tier 1: Renewable Biogas & RNG",
            envImpact: "-2.70 kg CO₂e / kg diverted",
            co2FactorKg: 2.70,
            valuePotential: "$1.80 / kg equivalent",
            valueFactorPerKg: 1.80,
            process: "Depackaging press separating non-organics, followed by thermophilic digestion yielding clean fuel and liquid biological nitrogen.",
            offtakerType: "Regional Anaerobic Digestion Hubs",
            processingTime: "18 days",
            scalability: "Very High"
          },
          {
            id: "fs-liquid-fertilizer",
            rank: 2,
            name: "Microbial Hydrolysate Liquid Bio-Fertilizer",
            matchPct: 84,
            badge: "Foliar Plant Nutrition",
            tier: "Tier 2: Organic Crop Nutrition",
            envImpact: "-1.90 kg CO₂e / kg diverted",
            co2FactorKg: 1.90,
            valuePotential: "$2.20 / kg ($88.00 total)",
            valueFactorPerKg: 2.20,
            process: "Enzymatic digester hydro-liquefaction pasteurized and stabilized with natural phosphoric acid for drip irrigation lines.",
            offtakerType: "Commercial Hydroponics & Orchards",
            processingTime: "72 hours",
            scalability: "High"
          },
          {
            id: "fs-compost-bulked",
            rank: 3,
            name: "Aerated Compost (High Bulking Ratio 4:1)",
            matchPct: 70,
            badge: "Bulk Diverted Waste",
            tier: "Tier 3: Landfill Diversion",
            envImpact: "-1.10 kg CO₂e / kg diverted",
            co2FactorKg: 1.10,
            valuePotential: "$0.35 / kg ($14.00 total)",
            valueFactorPerKg: 0.35,
            process: "Requires heavy addition of wood mulch and yard trimmings to soak up excess moisture and prevent leachate runoff.",
            offtakerType: "Regional Composting Yards",
            processingTime: "60-75 days",
            scalability: "High"
          },
          {
            id: "fs-landfill-wet",
            rank: 4,
            name: "Standard Landfill Disposal (High Methane Risk)",
            matchPct: 15,
            badge: "⚠️ Worst Option — High Emissions",
            tier: "Tier 4: Environmental Hazard",
            envImpact: "+1.95 kg CO₂e / kg (Methane damage)",
            co2FactorKg: -1.95,
            valuePotential: "-$0.12 / kg (Tipping fee cost)",
            valueFactorPerKg: -0.12,
            process: "Anaerobic burial releases fugitive methane with 28x the global warming potential of carbon dioxide.",
            offtakerType: "Landfill Operator (Avoid)",
            processingTime: "Decades of pollution",
            scalability: "Linear waste trap"
          }
        ]
      },
      dry: {
        label: "Dry",
        moisturePct: 14,
        shelfLifeHours: 1440,
        description: "Thermally stabilized pre-consumer waste, spent bakery dough, grain trimmings, dried kitchen pulp.",
        topPickRationale: "Dry organic scraps are stable against odor and microbial spoilage. They serve as exceptional extruded livestock feed meal and high-calorific bio-char feedstocks.",
        pathways: [
          {
            id: "fs-compound-feed",
            rank: 1,
            name: "High-Nutrient Extruded Animal Feed Meal",
            matchPct: 94,
            badge: "Highest Economic Yield",
            tier: "Tier 1: Upcycled Animal Feed",
            envImpact: "-3.10 kg CO₂e / kg diverted",
            co2FactorKg: 3.10,
            valuePotential: "$2.95 / kg ($118.00 total)",
            valueFactorPerKg: 2.95,
            process: "High-shear thermal extrusion and pelleting conforming to strict veterinary nutrition standards, replacing virgin soy/corn meal.",
            offtakerType: "Certified Livestock & Poultry Feed Mills",
            processingTime: "12 hours",
            scalability: "High"
          },
          {
            id: "fs-biochar-pellets",
            rank: 2,
            name: "Soil Carbon Sequestration Bio-Char",
            matchPct: 85,
            badge: "Long-Term Carbon Removal",
            tier: "Tier 1: Carbon Removal Tech",
            envImpact: "-2.60 kg CO₂e / kg diverted",
            co2FactorKg: 2.60,
            valuePotential: "$2.30 / kg ($92.00 total)",
            valueFactorPerKg: 2.30,
            process: "Low-oxygen pyrolysis converting dry carbonaceous food waste into durable black carbon amending poor topsoils.",
            offtakerType: "Regenerative Carbon Ag Projects",
            processingTime: "6 hours",
            scalability: "High"
          },
          {
            id: "fs-dry-compost-mix",
            rank: 3,
            name: "Slow-Release Granular Organic Fertilizer",
            matchPct: 80,
            badge: "Precision Lawn & Turf",
            tier: "Tier 2: Packaged Garden Goods",
            envImpact: "-1.60 kg CO₂e / kg diverted",
            co2FactorKg: 1.60,
            valuePotential: "$1.40 / kg ($56.00 total)",
            valueFactorPerKg: 1.40,
            process: "Milled and blended with rock phosphate into shelf-stable gardener fertilizer bags.",
            offtakerType: "Organic Turf & Golf Course Management",
            processingTime: "24 hours",
            scalability: "High"
          },
          {
            id: "fs-pellet-boiler",
            rank: 4,
            name: "Auxiliary Thermal Fuel Pellets",
            matchPct: 68,
            badge: "Thermal Energy",
            tier: "Tier 3: Heat Displacement",
            envImpact: "-1.20 kg CO₂e / kg diverted",
            co2FactorKg: 1.20,
            valuePotential: "$0.70 / kg ($28.00 total)",
            valueFactorPerKg: 0.70,
            process: "Blended with sawdust for industrial pellet heating; ash content requires particulate cyclone filters.",
            offtakerType: "District Biomass Boilers",
            processingTime: "Immediate",
            scalability: "Medium"
          }
        ]
      }
    }
  }
};

const OFFTAKER_NETWORK = [
  {
    id: "offtaker-1",
    name: "VerdeBio Materials & Poly-Lab",
    category: "Biomaterials & Composites",
    distanceKm: 4.8,
    location: "Industrial District / Zone NW-3",
    acceptedResources: ["banana-peels", "citrus-peels", "coffee-grounds"],
    buyingRate: "$3.80 - $6.20 / kg",
    processingCapacity: "500 kg / day",
    certifications: ["ISO 14044 LCA Certified", "USDA BioPreferred Partner"],
    rating: 4.9,
    verified: true,
    contact: "dispatch@verdebio.tech"
  },
  {
    id: "offtaker-2",
    name: "Cascade Mycelium & Fungi Labs",
    category: "Myco-Farming & Packaging",
    distanceKm: 8.2,
    location: "Eastside AgriTech Corridor",
    acceptedResources: ["coffee-grounds", "rice-waste", "banana-peels"],
    buyingRate: "$2.80 - $4.50 / kg",
    processingCapacity: "1,200 kg / day",
    certifications: ["Regenerative Organic Alliance", "Zero Waste Circular Gold"],
    rating: 4.95,
    verified: true,
    contact: "grow@cascademyco.io"
  },
  {
    id: "offtaker-3",
    name: "Pacific BioCarbon & Water Remediation",
    category: "Engineered Adsorbents & Pyrolysis",
    distanceKm: 14.5,
    location: "Harbor Clean-Tech Park",
    acceptedResources: ["coconut-husk", "rice-waste", "citrus-peels"],
    buyingRate: "$4.20 - $7.50 / kg",
    processingCapacity: "3,000 kg / day",
    certifications: ["Puro.earth Carbon Removal Verified", "NSF-61 Clean Water"],
    rating: 4.88,
    verified: true,
    contact: "feedstock@pacificbiocarbon.com"
  },
  {
    id: "offtaker-4",
    name: "Emerald Metro Biogas & RNG Co-op",
    category: "Anaerobic Clean Energy",
    distanceKm: 6.1,
    location: "South Utility Basin",
    acceptedResources: ["food-scraps", "banana-peels", "coffee-grounds"],
    buyingRate: "$1.20 - $2.40 / kg equiv",
    processingCapacity: "10,000 kg / day",
    certifications: ["EPA Renewable Fuel Standard", "CARB LCFS Tier 2"],
    rating: 4.78,
    verified: true,
    contact: "operations@emeraldmetrobiogas.org"
  },
  {
    id: "offtaker-5",
    name: "SoilOrigin Regenerative Compost Co.",
    category: "Living Soil & Vermiculture",
    distanceKm: 11.0,
    location: "Valley Agricultural Hub",
    acceptedResources: ["food-scraps", "coffee-grounds", "coconut-husk", "banana-peels", "citrus-peels", "rice-waste"],
    buyingRate: "$0.40 - $1.10 / kg",
    processingCapacity: "15,000 kg / day",
    certifications: ["OMRI Organic Listed", "US Composting Council STA"],
    rating: 4.92,
    verified: true,
    contact: "hello@soilorigin.org"
  }
];

const DEMO_PRESETS = [
  {
    name: "Banana Peels",
    resourceId: "banana-peels",
    quantity: 10,
    location: "Seattle, WA - Cafe District",
    condition: "fresh",
    tagline: "10 kg Fresh Peels → 94% Biomaterial Yield"
  },
  {
    name: "Coffee Grounds",
    resourceId: "coffee-grounds",
    quantity: 50,
    location: "Portland, OR - Roastery Row",
    condition: "wet",
    tagline: "50 kg Wet Grounds → High-Caloric Biogas"
  },
  {
    name: "Coconut Husk",
    resourceId: "coconut-husk",
    quantity: 120,
    location: "Honolulu, HI - Processing Dock",
    condition: "dry",
    tagline: "120 kg Dry Husk → 97% PFAS Water Carbon"
  },
  {
    name: "Citrus Peels",
    resourceId: "citrus-peels",
    quantity: 25,
    location: "San Francisco, CA - Juice Commissary",
    condition: "fresh",
    tagline: "25 kg Fresh Rinds → High-Value D-Limonene"
  },
  {
    name: "Rice Waste",
    resourceId: "rice-waste",
    quantity: 200,
    location: "Sacramento, CA - Valley Mill",
    condition: "dry",
    tagline: "200 kg Dry Hull → Nano-Silica EV Batteries"
  },
  {
    name: "Food Scraps",
    resourceId: "food-scraps",
    quantity: 40,
    location: "Austin, TX - Tech Campus Kitchen",
    condition: "fresh",
    tagline: "40 kg Scraps → 93% BSFL Insect Protein"
  }
];

// --- 2. INTELLIGENCE ENGINE ---
class ResourceIntelligenceEngine {
  constructor() {
    this.database = RESOURCE_DATABASE;
    this.offtakers = OFFTAKER_NETWORK;
  }

  analyze(input) {
    const { resourceId, quantityKg, location, condition } = input;
    const resource = this.database[resourceId];

    if (!resource) {
      throw new Error(`Resource '${resourceId}' not found in database.`);
    }

    const conditionData = resource.conditions[condition] || resource.conditions.fresh;
    const qty = Math.max(0.1, parseFloat(quantityKg) || 10);

    const rankedPathways = conditionData.pathways.map((pathway, index) => {
      const totalCo2Abated = Math.round(pathway.co2FactorKg * qty * 10) / 10;
      const totalValueUSD = Math.round(pathway.valueFactorPerKg * qty * 100) / 100;
      
      return {
        ...pathway,
        rank: index + 1,
        totalCo2Abated,
        totalValueUSD,
        formattedTotalValue: `$${totalValueUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        formattedTotalCo2: `${totalCo2Abated > 0 ? '-' : '+'}${Math.abs(totalCo2Abated).toFixed(1)} kg CO₂e`
      };
    });

    const bestPathway = rankedPathways[0];
    const divertedKg = Math.round(qty * 10) / 10;
    const netCo2Reduced = Math.max(0, bestPathway.totalCo2Abated);
    const netValueRecovered = Math.max(0, bestPathway.totalValueUSD);

    const carMilesAvoided = Math.round(netCo2Reduced * 2.48);
    const treeSeedlingYears = Math.round((netCo2Reduced / 21.77) * 10) / 10;
    const soilAreaRegeneratedM2 = Math.round(qty * 0.75 * 10) / 10;
    const waterRetentionGallons = Math.round(qty * 4.2);

    const standardCompostValue = Math.round(qty * 0.40 * 100) / 100;
    const landfillCostFee = Math.round(qty * 0.12 * 100) / 100;
    const valueMultiplier = standardCompostValue > 0 ? (netValueRecovered / standardCompostValue).toFixed(1) : "12.0";

    const matchingOfftakers = this.offtakers.filter(offtaker => 
      offtaker.acceptedResources.includes(resourceId)
    ).map(offtaker => {
      const transitEmissionsKg = Math.round(offtaker.distanceKm * 0.14 * 10) / 10;
      return {
        ...offtaker,
        transitEmissionsKg
      };
    });

    const batchId = `RES-${resourceId.substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}-${condition.substring(0, 1).toUpperCase()}`;

    return {
      timestamp: new Date().toISOString(),
      batchId,
      profile: {
        resourceId,
        name: resource.name,
        scientificName: resource.scientificName,
        icon: resource.icon,
        category: resource.category,
        quantityKg: qty,
        location: location || "Metropolitan Region",
        condition: conditionData.label,
        moisturePct: conditionData.moisturePct,
        shelfLifeHours: conditionData.shelfLifeHours,
        description: conditionData.description,
        composition: resource.composition
      },
      topRecommendation: {
        ...bestPathway,
        whySelected: conditionData.topPickRationale
      },
      rankedPathways,
      impact: {
        wasteDivertedKg: divertedKg,
        co2ReductionKg: netCo2Reduced,
        valueRecoveredUSD: netValueRecovered,
        formattedValueUSD: `$${netValueRecovered.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        equivalencies: {
          carMilesAvoided,
          treeSeedlingYears,
          soilAreaRegeneratedM2,
          waterRetentionGallons
        },
        comparisons: {
          resourceValue: netValueRecovered,
          compostValue: standardCompostValue,
          landfillPenalty: landfillCostFee,
          valueMultiplier
        }
      },
      matchingOfftakers,
      journeyMilestones: [
        {
          id: "SOURCE",
          label: "Source",
          title: "Origin & Feedstock Aggregation",
          status: "Completed",
          details: `${qty} kg of ${resource.name} logged at ${location || "Regional Hub"}. Condition verified as ${conditionData.label}.`
        },
        {
          id: "IDENTIFY",
          label: "Identify",
          title: "Biochemical & Moisture Fingerprint",
          status: "Completed",
          details: `Detected ~${conditionData.moisturePct}% moisture index. Cellular lignin/cellulose ratio aligned for ${bestPathway.tier}.`
        },
        {
          id: "ANALYZE",
          label: "Analyze",
          title: "Valorization Optimization",
          status: "Completed",
          details: `Ranked 4 potential valorization cascades. Identified ${bestPathway.name} as peak economic & carbon mitigation pathway.`
        },
        {
          id: "MATCH",
          label: "Match",
          title: "Regional Circular Network Query",
          status: "Matched",
          details: `Found ${matchingOfftakers.length} verified commercial off-takers within active logistics perimeter.`
        },
        {
          id: "RECOMMEND",
          label: "Recommend",
          title: "Actionable Dispatch & Impact Manifest",
          status: "Active",
          details: `Manifest ${batchId} ready for transfer pass generation and destination dispatch.`
        }
      ]
    };
  }
}

// --- 3. APPLICATION CONTROLLER ---
class ResourceApp {
  constructor() {
    this.engine = new ResourceIntelligenceEngine();
    this.soundEnabled = true;
    this.audioCtx = null;
    this.currentAnalysis = null;
    this.currentJourneyIndex = 4;

    this.initElements();
    this.initAudio();
    this.renderPresets();
    this.attachEventListeners();
    this.updateLivePreview();
  }

  initElements() {
    this.form = document.getElementById('resource-form');
    this.resourceSelect = document.getElementById('resource-select');
    this.quantityInput = document.getElementById('quantity-input');
    this.locationInput = document.getElementById('location-input');
    this.qtyMinusBtn = document.getElementById('qty-minus-btn');
    this.qtyPlusBtn = document.getElementById('qty-plus-btn');
    this.analyzeBtn = document.getElementById('analyze-submit-btn');

    this.liveIcon = document.getElementById('live-resource-icon');
    this.liveName = document.getElementById('live-resource-name');
    this.liveSci = document.getElementById('live-sci-name');
    this.liveDesc = document.getElementById('live-resource-desc');
    this.liveMoisture = document.getElementById('live-moisture-val');
    this.liveShelf = document.getElementById('live-shelflife-val');
    this.liveCarbon = document.getElementById('live-carbon-val');
    this.liveBioactive = document.getElementById('live-bioactive-val');

    this.scannerOverlay = document.getElementById('scanner-overlay');
    this.scannerMsg = document.getElementById('scanner-status-msg');
    this.scannerFill = document.getElementById('scanner-progress-fill');
    this.scannerIcon = document.getElementById('scanner-spin-icon');

    this.resultsSection = document.getElementById('results-section');
    this.navLinkResults = document.getElementById('nav-link-results');
    
    this.resProfileIcon = document.getElementById('res-profile-icon');
    this.resProfileName = document.getElementById('res-profile-name');
    this.resProfileSci = document.getElementById('res-profile-sci');
    this.resProfileQty = document.getElementById('res-profile-qty');
    this.resProfileLoc = document.getElementById('res-profile-loc');
    this.resProfileCond = document.getElementById('res-profile-cond');
    this.resProfileShelf = document.getElementById('res-profile-shelf');

    this.bestMatchPct = document.getElementById('best-match-pct');
    this.bestAppTitle = document.getElementById('best-app-title');
    this.bestWhyText = document.getElementById('best-why-text');
    this.bestValueVal = document.getElementById('best-value-val');
    this.bestValueRate = document.getElementById('best-value-rate');
    this.bestCo2Val = document.getElementById('best-co2-val');
    this.bestTimeVal = document.getElementById('best-time-val');
    this.bestOfftakerSub = document.getElementById('best-offtaker-sub');
    this.btnDispatchBest = document.getElementById('btn-dispatch-best');
    this.btnManifestTrigger = document.getElementById('btn-manifest-trigger');

    this.rankedList = document.getElementById('ranked-pathways-list');

    this.journeyNodesContainer = document.getElementById('journey-nodes-container');
    this.journeyBeam = document.getElementById('journey-progress-beam');
    this.journeyStepTitle = document.getElementById('journey-step-title');
    this.journeyStepDesc = document.getElementById('journey-step-desc');
    this.journeyStepStatus = document.getElementById('journey-step-status');

    this.impactValDiverted = document.getElementById('impact-val-diverted');
    this.impactValCo2 = document.getElementById('impact-val-co2');
    this.impactValDollars = document.getElementById('impact-val-dollars');
    this.impactMultiplierTag = document.getElementById('impact-multiplier-tag');
    this.compFillResource = document.getElementById('comp-fill-resource');
    this.compValResource = document.getElementById('comp-val-resource');
    this.compFillCompost = document.getElementById('comp-fill-compost');
    this.compValCompost = document.getElementById('comp-val-compost');
    this.compValLandfill = document.getElementById('comp-val-landfill');
    this.equivCarMiles = document.getElementById('equiv-car-miles');
    this.equivTrees = document.getElementById('equiv-trees');
    this.equivSoil = document.getElementById('equiv-soil');
    this.equivWater = document.getElementById('equiv-water');

    this.modalOfftakers = document.getElementById('modal-offtakers');
    this.modalOfftakersList = document.getElementById('modal-offtakers-list');
    this.modalManifest = document.getElementById('modal-manifest');
    this.toastNotice = document.getElementById('toast-notice');
    this.toastText = document.getElementById('toast-text');
  }

  initAudio() {
    const soundToggle = document.getElementById('sound-toggle-btn');
    if (!soundToggle) return;
    soundToggle.addEventListener('click', () => {
      this.soundEnabled = !this.soundEnabled;
      soundToggle.style.color = this.soundEnabled ? 'var(--emerald-400)' : 'var(--text-muted)';
      this.showToast(this.soundEnabled ? 'Audio cues enabled' : 'Audio cues muted');
    });
  }

  playTone(frequency = 440, type = 'sine', duration = 0.08, delay = 0) {
    if (!this.soundEnabled) return;
    try {
      if (!this.audioCtx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.audioCtx = new AudioContext();
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
      setTimeout(() => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, this.audioCtx.currentTime);
        gain.gain.setValueAtTime(0.06, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start();
        osc.stop(this.audioCtx.currentTime + duration);
      }, delay * 1000);
    } catch (e) {}
  }

  playSuccessChime() {
    this.playTone(523.25, 'sine', 0.12, 0);
    this.playTone(659.25, 'sine', 0.12, 0.09);
    this.playTone(783.99, 'sine', 0.22, 0.18);
    this.playTone(1046.50, 'sine', 0.35, 0.28);
  }

  playClickSound() {
    this.playTone(800, 'triangle', 0.03, 0);
  }

  renderPresets() {
    const container = document.getElementById('preset-pills-container');
    if (!container) return;

    container.innerHTML = DEMO_PRESETS.map((preset) => {
      const res = RESOURCE_DATABASE[preset.resourceId];
      return `
        <button type="button" class="preset-pill" data-preset="${preset.resourceId}">
          <div class="pill-title">
            <span>${res.icon}</span>
            <span>${preset.name} (${preset.quantity}kg)</span>
          </div>
          <div class="pill-sub">${preset.tagline}</div>
        </button>
      `;
    }).join('');

    container.querySelectorAll('.preset-pill').forEach((btn, index) => {
      btn.addEventListener('click', () => {
        this.playClickSound();
        const preset = DEMO_PRESETS[index];
        this.applyPreset(preset);
      });
    });
  }

  applyPreset(preset) {
    this.resourceSelect.value = preset.resourceId;
    this.quantityInput.value = preset.quantity;
    this.locationInput.value = preset.location;

    const conditionRadio = document.querySelector(`input[name="condition"][value="${preset.condition}"]`);
    if (conditionRadio) {
      conditionRadio.checked = true;
    }

    this.updateLivePreview();
    this.showToast(`Loaded preset: ${preset.name} (${preset.quantity} kg)`);
    
    const analyzerElem = document.getElementById('analyzer');
    if (analyzerElem) {
      analyzerElem.scrollIntoView({ behavior: 'smooth' });
    }

    setTimeout(() => {
      this.runAnalysis();
    }, 400);
  }

  attachEventListeners() {
    this.resourceSelect.addEventListener('change', () => {
      this.playClickSound();
      this.updateLivePreview();
    });

    document.querySelectorAll('input[name="condition"]').forEach(radio => {
      radio.addEventListener('change', () => {
        this.playClickSound();
        this.updateLivePreview();
      });
    });

    this.quantityInput.addEventListener('input', () => {
      this.updateLivePreview();
    });

    this.qtyMinusBtn.addEventListener('click', () => {
      this.playClickSound();
      let val = Math.max(1, parseFloat(this.quantityInput.value || 10) - 5);
      this.quantityInput.value = val;
      this.updateLivePreview();
    });

    this.qtyPlusBtn.addEventListener('click', () => {
      this.playClickSound();
      let val = parseFloat(this.quantityInput.value || 10) + 5;
      this.quantityInput.value = val;
      this.updateLivePreview();
    });

    document.querySelectorAll('.quick-qty-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        this.playClickSound();
        const addQty = parseFloat(tag.dataset.qty);
        let val = (parseFloat(this.quantityInput.value) || 0) + addQty;
        this.quantityInput.value = val;
        this.updateLivePreview();
      });
    });

    document.querySelectorAll('.loc-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        this.playClickSound();
        this.locationInput.value = tag.dataset.loc;
      });
    });

    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.runAnalysis();
    });

    this.btnDispatchBest.addEventListener('click', () => {
      this.playClickSound();
      this.openOfftakersModal();
    });

    const openOfftakersBtn = document.getElementById('btn-open-offtakers');
    if (openOfftakersBtn) {
      openOfftakersBtn.addEventListener('click', () => {
        this.playClickSound();
        this.openOfftakersModal();
      });
    }

    this.btnManifestTrigger.addEventListener('click', () => {
      this.playClickSound();
      this.openManifestModal();
    });

    const stepManifestBtn = document.getElementById('btn-step-manifest');
    if (stepManifestBtn) {
      stepManifestBtn.addEventListener('click', () => {
        this.playClickSound();
        this.openManifestModal();
      });
    }

    document.querySelectorAll('[data-close-modal]').forEach(btn => {
      btn.addEventListener('click', () => {
        this.playClickSound();
        this.closeModals();
      });
    });

    [this.modalOfftakers, this.modalManifest].forEach(modal => {
      if (modal) {
        modal.addEventListener('click', (e) => {
          if (e.target === modal) this.closeModals();
        });
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeModals();
    });

    const copyBtn = document.getElementById('btn-copy-manifest');
    if (copyBtn) {
      copyBtn.addEventListener('click', () => {
        this.copyManifestToClipboard();
      });
    }

    const printBtn = document.getElementById('btn-print-manifest');
    if (printBtn) {
      printBtn.addEventListener('click', () => {
        window.print();
      });
    }

    if (this.journeyNodesContainer) {
      this.journeyNodesContainer.querySelectorAll('.journey-node-item').forEach((node, index) => {
        node.addEventListener('click', () => {
          this.playClickSound();
          this.selectJourneyNode(index);
        });
      });
    }
  }

  getSelectedCondition() {
    const checked = document.querySelector('input[name="condition"]:checked');
    return checked ? checked.value : 'fresh';
  }

  updateLivePreview() {
    const resId = this.resourceSelect.value;
    const res = RESOURCE_DATABASE[resId];
    if (!res) return;

    const condition = this.getSelectedCondition();
    const condData = res.conditions[condition] || res.conditions.fresh;

    this.liveIcon.textContent = res.icon;
    this.liveName.textContent = res.name;
    this.liveSci.textContent = res.scientificName;
    this.liveDesc.textContent = condData.description;
    this.liveMoisture.textContent = `~${condData.moisturePct}% (${condData.label} State)`;
    this.liveShelf.textContent = `${condData.shelfLifeHours} hours`;

    const compKeys = Object.keys(res.composition).slice(0, 3);
    const compSummary = compKeys.map(k => `${k}: ${res.composition[k]}`).join(' • ');
    this.liveCarbon.textContent = res.composition.organicCarbon || res.composition.carbonContent || 'High Organic Matrix';
    this.liveBioactive.textContent = compSummary;
  }

  runAnalysis() {
    this.playTone(600, 'sine', 0.08, 0);

    const inputData = {
      resourceId: this.resourceSelect.value,
      quantityKg: parseFloat(this.quantityInput.value) || 10,
      location: this.locationInput.value || "Pacific Northwest Cluster",
      condition: this.getSelectedCondition()
    };

    this.scannerOverlay.classList.add('active');
    this.scannerFill.style.width = '0%';
    this.scannerIcon.textContent = RESOURCE_DATABASE[inputData.resourceId]?.icon || '🔬';

    const steps = [
      { text: "Characterizing cellular moisture & polymer matrix...", pct: "25%" },
      { text: "Querying LCA carbon abatement benchmarks...", pct: "55%" },
      { text: "Mapping 14 regional circular off-taker nodes...", pct: "82%" },
      { text: "Synthesizing optimal valorization ranking...", pct: "100%" }
    ];

    let stepIdx = 0;
    const interval = setInterval(() => {
      if (stepIdx < steps.length) {
        this.scannerMsg.textContent = steps[stepIdx].text;
        this.scannerFill.style.width = steps[stepIdx].pct;
        this.playTone(400 + stepIdx * 120, 'sine', 0.05, 0);
        stepIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          this.scannerOverlay.classList.remove('active');
          this.completeAnalysis(inputData);
        }, 250);
      }
    }, 260);
  }

  completeAnalysis(inputData) {
    this.currentAnalysis = this.engine.analyze(inputData);
    this.playSuccessChime();
    this.renderResults();

    this.resultsSection.classList.add('visible');
    this.navLinkResults.style.display = 'inline-flex';
    this.resultsSection.scrollIntoView({ behavior: 'smooth' });

    this.showToast(`Analyzed ${this.currentAnalysis.profile.quantityKg} kg ${this.currentAnalysis.profile.name}!`);
  }

  renderResults() {
    const data = this.currentAnalysis;
    if (!data) return;

    this.resProfileIcon.textContent = data.profile.icon;
    this.resProfileName.textContent = data.profile.name;
    this.resProfileSci.textContent = `${data.profile.scientificName} • Batch ${data.batchId}`;
    this.resProfileQty.textContent = `${data.profile.quantityKg.toLocaleString()} kg`;
    this.resProfileLoc.textContent = data.profile.location;
    this.resProfileCond.textContent = `${data.profile.condition} (~${data.profile.moisturePct}% H₂O)`;
    this.resProfileShelf.textContent = `${data.profile.shelfLifeHours} hours`;

    const top = data.topRecommendation;
    this.bestMatchPct.textContent = `${top.matchPct}%`;
    this.bestAppTitle.textContent = top.name;
    this.bestWhyText.textContent = top.whySelected;
    this.bestValueVal.textContent = top.formattedTotalValue;
    this.bestValueRate.textContent = `${top.valuePotential} wholesale`;
    this.bestCo2Val.textContent = top.formattedTotalCo2;
    this.bestTimeVal.textContent = top.processingTime;
    this.bestOfftakerSub.textContent = top.offtakerType;

    this.rankedList.innerHTML = data.rankedPathways.map((pathway) => {
      const isTop = pathway.rank === 1;
      return `
        <div class="pathway-card ${isTop ? 'is-top-pick' : ''}">
          <div class="pathway-card-inner">
            <div class="pathway-rank-badge">#${pathway.rank}</div>
            
            <div class="pathway-info">
              <h3>
                <span>${pathway.name}</span>
                <span class="pathway-tier-tag">${pathway.tier}</span>
                ${isTop ? '<span class="badge-pill" style="font-size: 0.72rem;">★ Top Match</span>' : ''}
              </h3>
              <p class="pathway-desc">${pathway.process}</p>
              
              <div class="pathway-metrics-strip">
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                  <span>Value Potential: <strong>${pathway.formattedTotalValue}</strong> (${pathway.valuePotential})</span>
                </div>
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
                  <span>Env Impact: <strong>${pathway.formattedTotalCo2}</strong></span>
                </div>
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                  <span>Turnaround: <strong>${pathway.processingTime}</strong></span>
                </div>
              </div>
            </div>

            <div class="pathway-score-box">
              <span class="pathway-pct-value">${pathway.matchPct}%</span>
              <div class="score-bar-mini">
                <div class="score-fill-mini" style="width: ${pathway.matchPct}%;"></div>
              </div>
              <span style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Match Score</span>
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.updateJourneyDisplay();

    this.impactValDiverted.textContent = `${data.impact.wasteDivertedKg.toLocaleString()} kg`;
    this.impactValCo2.textContent = `-${data.impact.co2ReductionKg.toFixed(1)} kg`;
    this.impactValDollars.textContent = data.impact.formattedValueUSD;
    this.impactMultiplierTag.textContent = `${data.impact.comparisons.valueMultiplier}x Value Multiplier`;

    this.compValResource.textContent = data.impact.formattedValueUSD;
    this.compValCompost.textContent = `$${data.impact.comparisons.compostValue.toFixed(2)}`;
    this.compValLandfill.textContent = `-$${data.impact.comparisons.landfillPenalty.toFixed(2)}`;

    this.equivCarMiles.textContent = `${data.impact.equivalencies.carMilesAvoided.toLocaleString()} Miles`;
    this.equivTrees.textContent = `${data.impact.equivalencies.treeSeedlingYears} Trees`;
    this.equivSoil.textContent = `${data.impact.equivalencies.soilAreaRegeneratedM2.toLocaleString()} m²`;
    this.equivWater.textContent = `${data.impact.equivalencies.waterRetentionGallons.toLocaleString()} Gallons`;

    this.renderManifestContent();
  }

  updateJourneyDisplay() {
    if (!this.currentAnalysis) return;
    const milestones = this.currentAnalysis.journeyMilestones;
    const activeMilestone = milestones[this.currentJourneyIndex] || milestones[4];

    this.journeyStepTitle.textContent = `${activeMilestone.id} → ${activeMilestone.title}`;
    this.journeyStepDesc.textContent = activeMilestone.details;
    this.journeyStepStatus.textContent = activeMilestone.status;

    const nodeElements = this.journeyNodesContainer.querySelectorAll('.journey-node-item');
    nodeElements.forEach((elem, idx) => {
      if (idx <= this.currentJourneyIndex) {
        elem.classList.add('is-active');
      } else {
        elem.classList.remove('is-active');
      }
    });

    const beamPct = ((this.currentJourneyIndex + 1) / 5) * 100;
    this.journeyBeam.style.width = `${Math.min(90, beamPct)}%`;
  }

  selectJourneyNode(index) {
    this.currentJourneyIndex = index;
    this.updateJourneyDisplay();
  }

  openOfftakersModal() {
    const offtakers = this.currentAnalysis?.matchingOfftakers || OFFTAKER_NETWORK;
    this.modalOfftakersList.innerHTML = offtakers.map(offtaker => `
      <div class="offtaker-item-card">
        <div class="offtaker-item-top">
          <span class="offtaker-name">${offtaker.name}</span>
          <span class="offtaker-dist">📍 ${offtaker.distanceKm} km (${offtaker.location})</span>
        </div>
        <div class="offtaker-tags">
          <span class="offtaker-tag-badge">★ ${offtaker.rating} Rating</span>
          <span class="offtaker-tag-badge">${offtaker.category}</span>
          <span class="offtaker-tag-badge">Cap: ${offtaker.processingCapacity}</span>
        </div>
        <div style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
          Verified Buying Rate: <strong style="color: var(--emerald-400);">${offtaker.buyingRate}</strong>
        </div>
        <div class="offtaker-action-row">
          <span style="font-size: 0.74rem; color: var(--text-muted);">${offtaker.certifications.join(' • ')}</span>
          <button type="button" class="btn btn-primary btn-sm" onclick="window.dispatchOfftaker('${offtaker.name}')">
            Request Dispatch
          </button>
        </div>
      </div>
    `).join('');

    this.modalOfftakers.classList.add('active');
  }

  openManifestModal() {
    if (!this.currentAnalysis) {
      this.runAnalysis();
    }
    this.renderManifestContent();
    this.modalManifest.classList.add('active');
  }

  renderManifestContent() {
    if (!this.currentAnalysis) return;
    const a = this.currentAnalysis;

    document.getElementById('manifest-batch-id').textContent = `BATCH #${a.batchId}`;
    document.getElementById('manifest-timestamp').textContent = `Generated: ${new Date().toLocaleString()} (Local Station)`;
    document.getElementById('m-resource-name').textContent = `${a.profile.name} (${a.profile.scientificName})`;
    document.getElementById('m-quantity').textContent = `${a.profile.quantityKg} kg`;
    document.getElementById('m-condition').textContent = `${a.profile.condition} (${a.profile.description})`;
    document.getElementById('m-moisture').textContent = `~${a.profile.moisturePct}% Moisture Content`;
    
    const assignedOfftaker = a.matchingOfftakers[0]?.name || "VerdeBio Materials & Poly-Lab";
    document.getElementById('m-destination').textContent = `${assignedOfftaker} (${a.profile.location})`;
    document.getElementById('m-pathway').textContent = `${a.topRecommendation.name} (${a.topRecommendation.matchPct}% Match)`;
    document.getElementById('m-co2').textContent = `${a.topRecommendation.formattedTotalCo2} Abated`;
    document.getElementById('m-value').textContent = `${a.topRecommendation.formattedTotalValue} (Settlement Est.)`;
  }

  closeModals() {
    this.modalOfftakers.classList.remove('active');
    this.modalManifest.classList.remove('active');
  }

  copyManifestToClipboard() {
    if (!this.currentAnalysis) return;
    const a = this.currentAnalysis;
    const text = `
=== RESOURCE CIRCULAR TRANSFER MANIFEST ===
BATCH: ${a.batchId}
RESOURCE: ${a.profile.name} (${a.profile.scientificName})
QUANTITY: ${a.profile.quantityKg} kg
CONDITION: ${a.profile.condition} (~${a.profile.moisturePct}% H2O)
ORIGIN: ${a.profile.location}
PATHWAY: ${a.topRecommendation.name} (Match: ${a.topRecommendation.matchPct}%)
ESTIMATED CO2 ABATEMENT: ${a.topRecommendation.formattedTotalCo2}
ESTIMATED VALUE RECOVERY: ${a.topRecommendation.formattedTotalValue}
VERIFIED DESTINATION: ${a.matchingOfftakers[0]?.name || 'Regional Bio-Hub'}
STATUS: CERTIFIED FOR TRANSFER PASS
==========================================
    `.trim();

    navigator.clipboard.writeText(text).then(() => {
      this.playSuccessChime();
      this.showToast('Copied Transfer Manifest to clipboard!');
    }).catch(() => {
      this.showToast('Transfer Manifest ready for print!');
    });
  }

  showToast(message) {
    this.toastText.textContent = message;
    this.toastNotice.classList.add('show');
    setTimeout(() => {
      this.toastNotice.classList.remove('show');
    }, 3200);
  }
}

window.dispatchOfftaker = function(name) {
  const modal = document.getElementById('modal-offtakers');
  if (modal) modal.classList.remove('active');
  
  const toastNotice = document.getElementById('toast-notice');
  const toastText = document.getElementById('toast-text');
  if (toastText && toastNotice) {
    toastText.textContent = `Dispatch requested to ${name}! Transfer manifest initiated.`;
    toastNotice.classList.add('show');
    setTimeout(() => toastNotice.classList.remove('show'), 3500);
  }

  setTimeout(() => {
    const manifestModal = document.getElementById('modal-manifest');
    if (manifestModal) manifestModal.classList.add('active');
  }, 400);
};

document.addEventListener('DOMContentLoaded', () => {
  window.reSourceApp = new ResourceApp();
});
