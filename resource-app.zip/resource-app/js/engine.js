// ReSource Intelligence Computation Engine
import { RESOURCE_DATABASE, OFFTAKER_NETWORK } from './data.js';

export class ResourceIntelligenceEngine {
  constructor() {
    this.database = RESOURCE_DATABASE;
    this.offtakers = OFFTAKER_NETWORK;
  }

  /**
   * Run full multi-dimensional valorization analysis
   * @param {Object} input - { resourceId, quantityKg, location, condition, storageTier }
   * @returns {Object} Comprehensive analysis results
   */
  analyze(input) {
    const { resourceId, quantityKg, location, condition } = input;
    const resource = this.database[resourceId];

    if (!resource) {
      throw new Error(`Resource '${resourceId}' not found in database.`);
    }

    const conditionData = resource.conditions[condition] || resource.conditions.fresh;
    const qty = Math.max(0.1, parseFloat(quantityKg) || 10);

    // Compute scaled metrics for each pathway
    const rankedPathways = conditionData.pathways.map((pathway, index) => {
      const totalCo2Abated = Math.round(pathway.co2FactorKg * qty * 10) / 10;
      const totalValueUSD = Math.round(pathway.valueFactorPerKg * qty * 100) / 100;
      
      return {
        ...pathway,
        rank: index + 1,
        totalCo2Abated,
        totalValueUSD,
        formattedTotalValue: `$${totalValueUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        formattedTotalCo2: `${totalCo2Abated > 0 ? '-' : '+'}${Math.abs(totalCo2Abated).toFixed(1)} kg CO₂e`
      };
    });

    const bestPathway = rankedPathways[0];

    // Compute high-level lifecycle impact metrics
    const divertedKg = Math.round(qty * 10) / 10;
    const netCo2Reduced = Math.max(0, bestPathway.totalCo2Abated);
    const netValueRecovered = Math.max(0, bestPathway.totalValueUSD);

    // Equivalencies (standard EPA / NREL conversion benchmarks)
    const carMilesAvoided = Math.round(netCo2Reduced * 2.48);
    const treeSeedlingYears = Math.round((netCo2Reduced / 21.77) * 10) / 10; // 1 tree seedling absorbs ~22kg/year
    const soilAreaRegeneratedM2 = Math.round(qty * 0.75 * 10) / 10;
    const waterRetentionGallons = Math.round(qty * 4.2);

    // Baseline comparisons
    const standardCompostValue = Math.round(qty * 0.40 * 100) / 100;
    const landfillCostFee = Math.round(qty * 0.12 * 100) / 100; // Tipping fee avoided
    const valueMultiplier = standardCompostValue > 0 ? (netValueRecovered / standardCompostValue).toFixed(1) : "12.0";

    // Matching off-takers
    const matchingOfftakers = this.offtakers.filter(offtaker => 
      offtaker.acceptedResources.includes(resourceId)
    ).map(offtaker => {
      // Calculate realistic transit emissions & net dispatch distance
      const transitEmissionsKg = Math.round(offtaker.distanceKm * 0.14 * 10) / 10;
      return {
        ...offtaker,
        transitEmissionsKg
      };
    });

    // Generate unique batch trace hash
    const batchId = `RES-${resourceId.substring(0, 3).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}-${condition.substring(0, 1).toUpperCase()}`;

    return {
      timestamp: new Date().toISOString(),
      batchId,
      profile: {
        resourceId,
        name: resource.name,
        scientificName: resource.scientificName,
        icon: resource.icon,
        category: resource.category,
        quantityKg: qty,
        location: location || "Metropolitan Region",
        condition: conditionData.label,
        moisturePct: conditionData.moisturePct,
        shelfLifeHours: conditionData.shelfLifeHours,
        description: conditionData.description,
        composition: resource.composition
      },
      topRecommendation: {
        ...bestPathway,
        whySelected: conditionData.topPickRationale
      },
      rankedPathways,
      impact: {
        wasteDivertedKg: divertedKg,
        co2ReductionKg: netCo2Reduced,
        valueRecoveredUSD: netValueRecovered,
        formattedValueUSD: `$${netValueRecovered.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        equivalencies: {
          carMilesAvoided,
          treeSeedlingYears,
          soilAreaRegeneratedM2,
          waterRetentionGallons
        },
        comparisons: {
          resourceValue: netValueRecovered,
          compostValue: standardCompostValue,
          landfillPenalty: landfillCostFee,
          valueMultiplier
        }
      },
      matchingOfftakers,
      journeyMilestones: [
        {
          id: "SOURCE",
          label: "Source",
          title: "Origin & Feedstock Aggregation",
          status: "Completed",
          details: `${qty} kg of ${resource.name} logged at ${location || "Regional Hub"}. Condition verified as ${conditionData.label}.`
        },
        {
          id: "IDENTIFY",
          label: "Identify",
          title: "Biochemical & Moisture Fingerprint",
          status: "Completed",
          details: `Detected ~${conditionData.moisturePct}% moisture index. Cellular lignin/cellulose ratio aligned for ${bestPathway.tier}.`
        },
        {
          id: "ANALYZE",
          label: "Analyze",
          title: "Valorization Optimization",
          status: "Completed",
          details: `Ranked 4 potential valorization cascades. Identified ${bestPathway.name} as peak economic & carbon mitigation pathway.`
        },
        {
          id: "MATCH",
          label: "Match",
          title: "Regional Circular Network Query",
          status: "Matched",
          details: `Found ${matchingOfftakers.length} verified commercial off-takers within active logistics perimeter.`
        },
        {
          id: "RECOMMEND",
          label: "Recommend",
          title: "Actionable Dispatch & Impact Manifest",
          status: "Active",
          details: `Manifest ${batchId} ready for transfer pass generation and destination dispatch.`
        }
      ]
    };
  }
}
