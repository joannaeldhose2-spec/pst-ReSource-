// ReSource Application Controller
import { RESOURCE_DATABASE, DEMO_PRESETS, OFFTAKER_NETWORK } from './data.js';
import { ResourceIntelligenceEngine } from './engine.js';

class ResourceApp {
  constructor() {
    this.engine = new ResourceIntelligenceEngine();
    this.soundEnabled = true;
    this.audioCtx = null;
    this.currentAnalysis = null;
    this.currentJourneyIndex = 4; // all 5 completed after analysis

    this.initElements();
    this.initAudio();
    this.renderPresets();
    this.attachEventListeners();
    this.updateLivePreview(); // Initial preview state
  }

  initElements() {
    // Form elements
    this.form = document.getElementById('resource-form');
    this.resourceSelect = document.getElementById('resource-select');
    this.quantityInput = document.getElementById('quantity-input');
    this.locationInput = document.getElementById('location-input');
    this.qtyMinusBtn = document.getElementById('qty-minus-btn');
    this.qtyPlusBtn = document.getElementById('qty-plus-btn');
    this.analyzeBtn = document.getElementById('analyze-submit-btn');

    // Live preview elements
    this.liveIcon = document.getElementById('live-resource-icon');
    this.liveName = document.getElementById('live-resource-name');
    this.liveSci = document.getElementById('live-sci-name');
    this.liveDesc = document.getElementById('live-resource-desc');
    this.liveMoisture = document.getElementById('live-moisture-val');
    this.liveShelf = document.getElementById('live-shelflife-val');
    this.liveCarbon = document.getElementById('live-carbon-val');
    this.liveBioactive = document.getElementById('live-bioactive-val');

    // Scanner overlay
    this.scannerOverlay = document.getElementById('scanner-overlay');
    this.scannerMsg = document.getElementById('scanner-status-msg');
    this.scannerFill = document.getElementById('scanner-progress-fill');
    this.scannerIcon = document.getElementById('scanner-spin-icon');

    // Results elements
    this.resultsSection = document.getElementById('results-section');
    this.navLinkResults = document.getElementById('nav-link-results');
    
    // Profile card
    this.resProfileIcon = document.getElementById('res-profile-icon');
    this.resProfileName = document.getElementById('res-profile-name');
    this.resProfileSci = document.getElementById('res-profile-sci');
    this.resProfileQty = document.getElementById('res-profile-qty');
    this.resProfileLoc = document.getElementById('res-profile-loc');
    this.resProfileCond = document.getElementById('res-profile-cond');
    this.resProfileShelf = document.getElementById('res-profile-shelf');

    // Best next use card
    this.bestMatchPct = document.getElementById('best-match-pct');
    this.bestAppTitle = document.getElementById('best-app-title');
    this.bestWhyText = document.getElementById('best-why-text');
    this.bestValueVal = document.getElementById('best-value-val');
    this.bestValueRate = document.getElementById('best-value-rate');
    this.bestCo2Val = document.getElementById('best-co2-val');
    this.bestTimeVal = document.getElementById('best-time-val');
    this.bestOfftakerSub = document.getElementById('best-offtaker-sub');
    this.btnDispatchBest = document.getElementById('btn-dispatch-best');
    this.btnManifestTrigger = document.getElementById('btn-manifest-trigger');

    // Ranked applications list
    this.rankedList = document.getElementById('ranked-pathways-list');

    // Journey elements
    this.journeyNodesContainer = document.getElementById('journey-nodes-container');
    this.journeyBeam = document.getElementById('journey-progress-beam');
    this.journeyStepTitle = document.getElementById('journey-step-title');
    this.journeyStepDesc = document.getElementById('journey-step-desc');
    this.journeyStepStatus = document.getElementById('journey-step-status');

    // Impact elements
    this.impactValDiverted = document.getElementById('impact-val-diverted');
    this.impactValCo2 = document.getElementById('impact-val-co2');
    this.impactValDollars = document.getElementById('impact-val-dollars');
    this.impactMultiplierTag = document.getElementById('impact-multiplier-tag');
    this.compFillResource = document.getElementById('comp-fill-resource');
    this.compValResource = document.getElementById('comp-val-resource');
    this.compFillCompost = document.getElementById('comp-fill-compost');
    this.compValCompost = document.getElementById('comp-val-compost');
    this.compValLandfill = document.getElementById('comp-val-landfill');
    this.equivCarMiles = document.getElementById('equiv-car-miles');
    this.equivTrees = document.getElementById('equiv-trees');
    this.equivSoil = document.getElementById('equiv-soil');
    this.equivWater = document.getElementById('equiv-water');

    // Modals
    this.modalOfftakers = document.getElementById('modal-offtakers');
    this.modalOfftakersList = document.getElementById('modal-offtakers-list');
    this.modalManifest = document.getElementById('modal-manifest');
    this.toastNotice = document.getElementById('toast-notice');
    this.toastText = document.getElementById('toast-text');
  }

  initAudio() {
    const soundToggle = document.getElementById('sound-toggle-btn');
    soundToggle.addEventListener('click', () => {
      this.soundEnabled = !this.soundEnabled;
      soundToggle.style.color = this.soundEnabled ? 'var(--emerald-400)' : 'var(--text-muted)';
      this.showToast(this.soundEnabled ? 'Audio cues enabled' : 'Audio cues muted');
    });
  }

  playTone(frequency = 440, type = 'sine', duration = 0.08, delay = 0) {
    if (!this.soundEnabled) return;
    try {
      if (!this.audioCtx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        this.audioCtx = new AudioContext();
      }
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
      setTimeout(() => {
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, this.audioCtx.currentTime);
        gain.gain.setValueAtTime(0.06, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.audioCtx.currentTime + duration);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start();
        osc.stop(this.audioCtx.currentTime + duration);
      }, delay * 1000);
    } catch (e) {
      // Audio autoplay policy fallback
    }
  }

  playSuccessChime() {
    this.playTone(523.25, 'sine', 0.12, 0);       // C5
    this.playTone(659.25, 'sine', 0.12, 0.09);    // E5
    this.playTone(783.99, 'sine', 0.22, 0.18);    // G5
    this.playTone(1046.50, 'sine', 0.35, 0.28);   // C6
  }

  playClickSound() {
    this.playTone(800, 'triangle', 0.03, 0);
  }

  renderPresets() {
    const container = document.getElementById('preset-pills-container');
    if (!container) return;

    container.innerHTML = DEMO_PRESETS.map((preset) => {
      const res = RESOURCE_DATABASE[preset.resourceId];
      return `
        <button type="button" class="preset-pill" data-preset="${preset.resourceId}">
          <div class="pill-title">
            <span>${res.icon}</span>
            <span>${preset.name} (${preset.quantity}kg)</span>
          </div>
          <div class="pill-sub">${preset.tagline}</div>
        </button>
      `;
    }).join('');

    container.querySelectorAll('.preset-pill').forEach((btn, index) => {
      btn.addEventListener('click', () => {
        this.playClickSound();
        const preset = DEMO_PRESETS[index];
        this.applyPreset(preset);
      });
    });
  }

  applyPreset(preset) {
    this.resourceSelect.value = preset.resourceId;
    this.quantityInput.value = preset.quantity;
    this.locationInput.value = preset.location;

    const conditionRadio = document.querySelector(`input[name="condition"][value="${preset.condition}"]`);
    if (conditionRadio) {
      conditionRadio.checked = true;
    }

    this.updateLivePreview();
    this.showToast(`Loaded preset: ${preset.name} (${preset.quantity} kg)`);
    
    // Auto-scroll to analyzer and trigger analysis
    const analyzerElem = document.getElementById('analyzer');
    if (analyzerElem) {
      analyzerElem.scrollIntoView({ behavior: 'smooth' });
    }

    setTimeout(() => {
      this.runAnalysis();
    }, 400);
  }

  attachEventListeners() {
    // Dynamic change listeners for live characterization preview
    this.resourceSelect.addEventListener('change', () => {
      this.playClickSound();
      this.updateLivePreview();
    });

    document.querySelectorAll('input[name="condition"]').forEach(radio => {
      radio.addEventListener('change', () => {
        this.playClickSound();
        this.updateLivePreview();
      });
    });

    this.quantityInput.addEventListener('input', () => {
      this.updateLivePreview();
    });

    // Plus/Minus Buttons
    this.qtyMinusBtn.addEventListener('click', () => {
      this.playClickSound();
      let val = Math.max(1, parseFloat(this.quantityInput.value || 10) - 5);
      this.quantityInput.value = val;
      this.updateLivePreview();
    });

    this.qtyPlusBtn.addEventListener('click', () => {
      this.playClickSound();
      let val = parseFloat(this.quantityInput.value || 10) + 5;
      this.quantityInput.value = val;
      this.updateLivePreview();
    });

    // Quick quantity tag buttons
    document.querySelectorAll('.quick-qty-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        this.playClickSound();
        const addQty = parseFloat(tag.dataset.qty);
        let val = (parseFloat(this.quantityInput.value) || 0) + addQty;
        this.quantityInput.value = val;
        this.updateLivePreview();
      });
    });

    // Quick location tags
    document.querySelectorAll('.loc-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        this.playClickSound();
        this.locationInput.value = tag.dataset.loc;
      });
    });

    // Form submit
    this.form.addEventListener('submit', (e) => {
      e.preventDefault();
      this.runAnalysis();
    });

    // Off-taker and Manifest modal triggers
    this.btnDispatchBest.addEventListener('click', () => {
      this.playClickSound();
      this.openOfftakersModal();
    });

    document.getElementById('btn-open-offtakers').addEventListener('click', () => {
      this.playClickSound();
      this.openOfftakersModal();
    });

    this.btnManifestTrigger.addEventListener('click', () => {
      this.playClickSound();
      this.openManifestModal();
    });

    document.getElementById('btn-step-manifest').addEventListener('click', () => {
      this.playClickSound();
      this.openManifestModal();
    });

    // Modal close listeners
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
      btn.addEventListener('click', () => {
        this.playClickSound();
        this.closeModals();
      });
    });

    [this.modalOfftakers, this.modalManifest].forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) this.closeModals();
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeModals();
    });

    // Manifest actions
    document.getElementById('btn-copy-manifest').addEventListener('click', () => {
      this.copyManifestToClipboard();
    });

    document.getElementById('btn-print-manifest').addEventListener('click', () => {
      window.print();
    });

    // Journey node clicks
    this.journeyNodesContainer.querySelectorAll('.journey-node-item').forEach((node, index) => {
      node.addEventListener('click', () => {
        this.playClickSound();
        this.selectJourneyNode(index);
      });
    });
  }

  getSelectedCondition() {
    const checked = document.querySelector('input[name="condition"]:checked');
    return checked ? checked.value : 'fresh';
  }

  updateLivePreview() {
    const resId = this.resourceSelect.value;
    const res = RESOURCE_DATABASE[resId];
    if (!res) return;

    const condition = this.getSelectedCondition();
    const condData = res.conditions[condition] || res.conditions.fresh;

    this.liveIcon.textContent = res.icon;
    this.liveName.textContent = res.name;
    this.liveSci.textContent = res.scientificName;
    this.liveDesc.textContent = condData.description;
    this.liveMoisture.textContent = `~${condData.moisturePct}% (${condData.label} State)`;
    this.liveShelf.textContent = `${condData.shelfLifeHours} hours`;

    // Dynamic bio-composition highlights
    const compKeys = Object.keys(res.composition).slice(0, 3);
    const compSummary = compKeys.map(k => `${k}: ${res.composition[k]}`).join(' • ');
    this.liveCarbon.textContent = res.composition.organicCarbon || res.composition.carbonContent || 'High Organic Matrix';
    this.liveBioactive.textContent = compSummary;
  }

  runAnalysis() {
    this.playTone(600, 'sine', 0.08, 0);

    const inputData = {
      resourceId: this.resourceSelect.value,
      quantityKg: parseFloat(this.quantityInput.value) || 10,
      location: this.locationInput.value || "Pacific Northwest Cluster",
      condition: this.getSelectedCondition()
    };

    // Trigger analysis HUD animation
    this.scannerOverlay.classList.add('active');
    this.scannerFill.style.width = '0%';
    this.scannerIcon.textContent = RESOURCE_DATABASE[inputData.resourceId]?.icon || '🔬';

    const steps = [
      { text: "Characterizing cellular moisture & polymer matrix...", pct: "25%" },
      { text: "Querying LCA carbon abatement benchmarks...", pct: "55%" },
      { text: "Mapping 14 regional circular off-taker nodes...", pct: "82%" },
      { text: "Synthesizing optimal valorization ranking...", pct: "100%" }
    ];

    let stepIdx = 0;
    const interval = setInterval(() => {
      if (stepIdx < steps.length) {
        this.scannerMsg.textContent = steps[stepIdx].text;
        this.scannerFill.style.width = steps[stepIdx].pct;
        this.playTone(400 + stepIdx * 120, 'sine', 0.05, 0);
        stepIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          this.scannerOverlay.classList.remove('active');
          this.completeAnalysis(inputData);
        }, 250);
      }
    }, 280);
  }

  completeAnalysis(inputData) {
    this.currentAnalysis = this.engine.analyze(inputData);
    this.playSuccessChime();

    // Render results
    this.renderResults();

    // Reveal results section
    this.resultsSection.classList.add('visible');
    this.navLinkResults.style.display = 'inline-flex';

    // Smooth scroll to results
    this.resultsSection.scrollIntoView({ behavior: 'smooth' });

    this.showToast(`Analyzed ${this.currentAnalysis.profile.quantityKg} kg ${this.currentAnalysis.profile.name}!`);
  }

  renderResults() {
    const data = this.currentAnalysis;
    if (!data) return;

    // 1. Profile Card
    this.resProfileIcon.textContent = data.profile.icon;
    this.resProfileName.textContent = data.profile.name;
    this.resProfileSci.textContent = `${data.profile.scientificName} • Batch ${data.batchId}`;
    this.resProfileQty.textContent = `${data.profile.quantityKg.toLocaleString()} kg`;
    this.resProfileLoc.textContent = data.profile.location;
    this.resProfileCond.textContent = `${data.profile.condition} (~${data.profile.moisturePct}% H₂O)`;
    this.resProfileShelf.textContent = `${data.profile.shelfLifeHours} hours`;

    // 2. Best Next Use Hero Card
    const top = data.topRecommendation;
    this.bestMatchPct.textContent = `${top.matchPct}%`;
    this.bestAppTitle.textContent = top.name;
    this.bestWhyText.textContent = top.whySelected;
    this.bestValueVal.textContent = top.formattedTotalValue;
    this.bestValueRate.textContent = `${top.valuePotential} wholesale`;
    this.bestCo2Val.textContent = top.formattedTotalCo2;
    this.bestTimeVal.textContent = top.processingTime;
    this.bestOfftakerSub.textContent = top.offtakerType;

    // 3. Ranked Pathways List
    this.rankedList.innerHTML = data.rankedPathways.map((pathway) => {
      const isTop = pathway.rank === 1;
      return `
        <div class="pathway-card ${isTop ? 'is-top-pick' : ''}">
          <div class="pathway-card-inner">
            <div class="pathway-rank-badge">#${pathway.rank}</div>
            
            <div class="pathway-info">
              <h3>
                <span>${pathway.name}</span>
                <span class="pathway-tier-tag">${pathway.tier}</span>
                ${isTop ? '<span class="badge-pill" style="font-size: 0.72rem;">★ Top Match</span>' : ''}
              </h3>
              <p class="pathway-desc">${pathway.process}</p>
              
              <div class="pathway-metrics-strip">
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                  <span>Value Potential: <strong>${pathway.formattedTotalValue}</strong> (${pathway.valuePotential})</span>
                </div>
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
                  <span>Env Impact: <strong>${pathway.formattedTotalCo2}</strong></span>
                </div>
                <div class="metric-strip-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                  <span>Turnaround: <strong>${pathway.processingTime}</strong></span>
                </div>
              </div>
            </div>

            <div class="pathway-score-box">
              <span class="pathway-pct-value">${pathway.matchPct}%</span>
              <div class="score-bar-mini">
                <div class="score-fill-mini" style="width: ${pathway.matchPct}%;"></div>
              </div>
              <span style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase;">Match Score</span>
            </div>
          </div>
        </div>
      `;
    }).join('');

    // 4. Update Journey Nodes
    this.updateJourneyDisplay();

    // 5. Update Impact Panel
    this.impactValDiverted.textContent = `${data.impact.wasteDivertedKg.toLocaleString()} kg`;
    this.impactValCo2.textContent = `-${data.impact.co2ReductionKg.toFixed(1)} kg`;
    this.impactValDollars.textContent = data.impact.formattedValueUSD;
    this.impactMultiplierTag.textContent = `${data.impact.comparisons.valueMultiplier}x Value Multiplier`;

    // Comparison Bars
    this.compValResource.textContent = data.impact.formattedValueUSD;
    this.compValCompost.textContent = `$${data.impact.comparisons.compostValue.toFixed(2)}`;
    this.compValLandfill.textContent = `-$${data.impact.comparisons.landfillPenalty.toFixed(2)}`;

    // Equivalents
    this.equivCarMiles.textContent = `${data.impact.equivalencies.carMilesAvoided.toLocaleString()} Miles`;
    this.equivTrees.textContent = `${data.impact.equivalencies.treeSeedlingYears} Trees`;
    this.equivSoil.textContent = `${data.impact.equivalencies.soilAreaRegeneratedM2.toLocaleString()} m²`;
    this.equivWater.textContent = `${data.impact.equivalencies.waterRetentionGallons.toLocaleString()} Gallons`;

    // Populate Manifest Template
    this.renderManifestContent();
  }

  updateJourneyDisplay() {
    if (!this.currentAnalysis) return;
    const milestones = this.currentAnalysis.journeyMilestones;
    const activeMilestone = milestones[this.currentJourneyIndex] || milestones[4];

    this.journeyStepTitle = document.getElementById('journey-step-title');
    this.journeyStepDesc = document.getElementById('journey-step-desc');
    this.journeyStepStatus = document.getElementById('journey-step-status');

    this.journeyStepTitle.textContent = `${activeMilestone.id} → ${activeMilestone.title}`;
    this.journeyStepDesc.textContent = activeMilestone.details;
    this.journeyStepStatus.textContent = activeMilestone.status;

    // Highlight nodes
    const nodeElements = this.journeyNodesContainer.querySelectorAll('.journey-node-item');
    nodeElements.forEach((elem, idx) => {
      if (idx <= this.currentJourneyIndex) {
        elem.classList.add('is-active');
      } else {
        elem.classList.remove('is-active');
      }
    });

    const beamPct = ((this.currentJourneyIndex + 1) / 5) * 100;
    this.journeyBeam.style.width = `${Math.min(90, beamPct)}%`;
  }

  selectJourneyNode(index) {
    this.currentJourneyIndex = index;
    this.updateJourneyDisplay();
  }

  openOfftakersModal() {
    const offtakers = this.currentAnalysis?.matchingOfftakers || OFFTAKER_NETWORK;
    this.modalOfftakersList.innerHTML = offtakers.map(offtaker => `
      <div class="offtaker-item-card">
        <div class="offtaker-item-top">
          <span class="offtaker-name">${offtaker.name}</span>
          <span class="offtaker-dist">📍 ${offtaker.distanceKm} km (${offtaker.location})</span>
        </div>
        <div class="offtaker-tags">
          <span class="offtaker-tag-badge">★ ${offtaker.rating} Rating</span>
          <span class="offtaker-tag-badge">${offtaker.category}</span>
          <span class="offtaker-tag-badge">Cap: ${offtaker.processingCapacity}</span>
        </div>
        <div style="font-size: 0.82rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
          Verified Buying Rate: <strong style="color: var(--emerald-400);">${offtaker.buyingRate}</strong>
        </div>
        <div class="offtaker-action-row">
          <span style="font-size: 0.74rem; color: var(--text-muted);">${offtaker.certifications.join(' • ')}</span>
          <button type="button" class="btn btn-primary btn-sm" onclick="window.dispatchOfftaker('${offtaker.name}')">
            Request Dispatch
          </button>
        </div>
      </div>
    `).join('');

    this.modalOfftakers.classList.add('active');
  }

  openManifestModal() {
    if (!this.currentAnalysis) {
      this.runAnalysis();
    }
    this.renderManifestContent();
    this.modalManifest.classList.add('active');
  }

  renderManifestContent() {
    if (!this.currentAnalysis) return;
    const a = this.currentAnalysis;

    document.getElementById('manifest-batch-id').textContent = `BATCH #${a.batchId}`;
    document.getElementById('manifest-timestamp').textContent = `Generated: ${new Date().toLocaleString()} (Local Station)`;
    document.getElementById('m-resource-name').textContent = `${a.profile.name} (${a.profile.scientificName})`;
    document.getElementById('m-quantity').textContent = `${a.profile.quantityKg} kg`;
    document.getElementById('m-condition').textContent = `${a.profile.condition} (${a.profile.description})`;
    document.getElementById('m-moisture').textContent = `~${a.profile.moisturePct}% Moisture Content`;
    
    const assignedOfftaker = a.matchingOfftakers[0]?.name || "VerdeBio Materials & Poly-Lab";
    document.getElementById('m-destination').textContent = `${assignedOfftaker} (${a.profile.location})`;
    document.getElementById('m-pathway').textContent = `${a.topRecommendation.name} (${a.topRecommendation.matchPct}% Match)`;
    document.getElementById('m-co2').textContent = `${a.topRecommendation.formattedTotalCo2} Abated`;
    document.getElementById('m-value').textContent = `${a.topRecommendation.formattedTotalValue} (Settlement Est.)`;
  }

  closeModals() {
    this.modalOfftakers.classList.remove('active');
    this.modalManifest.classList.remove('active');
  }

  copyManifestToClipboard() {
    if (!this.currentAnalysis) return;
    const a = this.currentAnalysis;
    const text = `
=== RESOURCE CIRCULAR TRANSFER MANIFEST ===
BATCH: ${a.batchId}
RESOURCE: ${a.profile.name} (${a.profile.scientificName})
QUANTITY: ${a.profile.quantityKg} kg
CONDITION: ${a.profile.condition} (~${a.profile.moisturePct}% H2O)
ORIGIN: ${a.profile.location}
PATHWAY: ${a.topRecommendation.name} (Match: ${a.topRecommendation.matchPct}%)
ESTIMATED CO2 ABATEMENT: ${a.topRecommendation.formattedTotalCo2}
ESTIMATED VALUE RECOVERY: ${a.topRecommendation.formattedTotalValue}
VERIFIED DESTINATION: ${a.matchingOfftakers[0]?.name || 'Regional Bio-Hub'}
STATUS: CERTIFIED FOR TRANSFER PASS
==========================================
    `.trim();

    navigator.clipboard.writeText(text).then(() => {
      this.playSuccessChime();
      this.showToast('Copied Transfer Manifest to clipboard!');
    }).catch(() => {
      this.showToast('Transfer Manifest ready for print!');
    });
  }

  showToast(message) {
    this.toastText.textContent = message;
    this.toastNotice.classList.add('show');
    setTimeout(() => {
      this.toastNotice.classList.remove('show');
    }, 3200);
  }
}

// Global hook for inline dispatch button in modal
window.dispatchOfftaker = function(name) {
  const modal = document.getElementById('modal-offtakers');
  if (modal) modal.classList.remove('active');
  
  const toastNotice = document.getElementById('toast-notice');
  const toastText = document.getElementById('toast-text');
  if (toastText && toastNotice) {
    toastText.textContent = `Dispatch requested to ${name}! Transfer manifest initiated.`;
    toastNotice.classList.add('show');
    setTimeout(() => toastNotice.classList.remove('show'), 3500);
  }

  setTimeout(() => {
    const manifestModal = document.getElementById('modal-manifest');
    if (manifestModal) manifestModal.classList.add('active');
  }, 400);
};

// Initialize when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.reSourceApp = new ResourceApp();
});
