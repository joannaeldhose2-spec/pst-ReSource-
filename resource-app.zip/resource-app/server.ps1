# ReSource - Lightweight Local HTTP Server (Zero Dependencies)
# Runs via built-in Windows PowerShell .NET HttpListener

param(
    [int]$Port = 3000
)

$prefix = "http://localhost:$Port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
    Write-Host "==========================================================" -ForegroundColor Green
    Write-Host " ReSource Web App is running live at: $prefix" -ForegroundColor Cyan
    Write-Host " Press Ctrl+C in PowerShell to stop the server." -ForegroundColor Yellow
    Write-Host "==========================================================" -ForegroundColor Green

    # Attempt to open browser automatically
    Start-Process $prefix

    $currentDir = $PSScriptRoot
    if (-not $currentDir) { $currentDir = Get-Location }

    $mimeTypes = @{
        ".html" = "text/html; charset=utf-8"
        ".htm"  = "text/html; charset=utf-8"
        ".css"  = "text/css; charset=utf-8"
        ".js"   = "application/javascript; charset=utf-8"
        ".json" = "application/json; charset=utf-8"
        ".png"  = "image/png"
        ".jpg"  = "image/jpeg"
        ".jpeg" = "image/jpeg"
        ".svg"  = "image/svg+xml"
        ".ico"  = "image/x-icon"
    }

    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        $urlPath = $request.Url.LocalPath
        if ($urlPath -eq "/" -or [string]::IsNullOrWhiteSpace($urlPath)) {
            $urlPath = "/index.html"
        }

        $localFilePath = Join-Path $currentDir $urlPath.TrimStart('/')

        if (Test-Path $localFilePath -PathType Leaf) {
            $extension = [System.IO.Path]::GetExtension($localFilePath).ToLower()
            $contentType = "application/octet-stream"
            if ($mimeTypes.ContainsKey($extension)) {
                $contentType = $mimeTypes[$extension]
            }

            $response.ContentType = $contentType
            $response.Headers.Add("Access-Control-Allow-Origin", "*")
            $fileBytes = [System.IO.File]::ReadAllBytes($localFilePath)
            $response.ContentLength64 = $fileBytes.Length
            $response.OutputStream.Write($fileBytes, 0, $fileBytes.Length)
            $response.StatusCode = 200
        } else {
            $response.StatusCode = 404
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
        }
        $response.Close()
    }
}
catch {
    Write-Host "Server error or terminated: $_" -ForegroundColor Red
}
finally {
    $listener.Stop()
    $listener.Close()
}
